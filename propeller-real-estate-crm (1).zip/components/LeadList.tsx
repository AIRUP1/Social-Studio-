
import React, { useState } from 'react';
import { Lead, LeadStatus } from '../types';
import { STATUS_COLORS } from '../constants';
import { Plus, Search, Edit2, X, ChevronRight } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface LeadListProps {
  leads: Lead[];
  onSelectLead: (lead: Lead) => void;
  onAddLead: (lead: Omit<Lead, 'id'>) => void;
  onUpdateLead: (lead: Lead) => void;
}

const LeadModal: React.FC<{ lead?: Lead; onClose: () => void; onSave: (l: any) => void }> = ({ lead, onClose, onSave }) => {
  const [formData, setFormData] = useState({
    name: lead?.name || '',
    email: lead?.email || '',
    phone: lead?.phone || '',
    status: lead?.status || 'New',
    value: lead?.value || 0,
    propertyInterest: lead?.propertyInterest || '',
    location: lead?.location || '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      ...lead,
      ...formData,
      notes: lead?.notes || [],
      lastInteraction: lead?.lastInteraction || new Date().toISOString().split('T')[0],
      createdAt: lead?.createdAt || new Date().toISOString().split('T')[0],
    });
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 bg-gray-900/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <motion.div initial={{ scale: 0.9, y: 20 }} animate={{ scale: 1, y: 0 }} exit={{ scale: 0.9, y: 20 }} className="bg-white rounded-[32px] w-full max-w-lg p-8 shadow-2xl">
        <div className="flex justify-between items-center mb-8">
          <h3 className="text-2xl font-black text-gray-900 tracking-tight">{lead ? 'Edit Lead' : 'New Lead'}</h3>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-xl transition-colors"><X className="w-5 h-5 text-gray-400" /></button>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1">
              <label className="text-[10px] font-black uppercase text-gray-400 tracking-widest px-1">Full Name</label>
              <input required value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} className="w-full px-4 py-2 bg-gray-50 border-none rounded-xl focus:ring-2 focus:ring-indigo-500 font-medium" />
            </div>
            <div className="space-y-1">
              <label className="text-[10px] font-black uppercase text-gray-400 tracking-widest px-1">Email</label>
              <input required type="email" value={formData.email} onChange={e => setFormData({...formData, email: e.target.value})} className="w-full px-4 py-2 bg-gray-50 border-none rounded-xl focus:ring-2 focus:ring-indigo-500 font-medium" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1">
              <label className="text-[10px] font-black uppercase text-gray-400 tracking-widest px-1">Property Interest</label>
              <input value={formData.propertyInterest} onChange={e => setFormData({...formData, propertyInterest: e.target.value})} className="w-full px-4 py-2 bg-gray-50 border-none rounded-xl focus:ring-2 focus:ring-indigo-500 font-medium" />
            </div>
            <div className="space-y-1">
              <label className="text-[10px] font-black uppercase text-gray-400 tracking-widest px-1">Est. Value</label>
              <input type="number" value={formData.value} onChange={e => setFormData({...formData, value: Number(e.target.value)})} className="w-full px-4 py-2 bg-gray-50 border-none rounded-xl focus:ring-2 focus:ring-indigo-500 font-medium" />
            </div>
          </div>
          <div className="space-y-1">
            <label className="text-[10px] font-black uppercase text-gray-400 tracking-widest px-1">Status</label>
            <select value={formData.status} onChange={e => setFormData({...formData, status: e.target.value as LeadStatus})} className="w-full px-4 py-2 bg-gray-50 border-none rounded-xl focus:ring-2 focus:ring-indigo-500 font-medium appearance-none">
              {['New', 'Contacted', 'Qualified', 'Proposal', 'Negotiation', 'Closed', 'Lost'].map(s => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>
          <div className="pt-6 flex space-x-3">
            <button type="button" onClick={onClose} className="flex-1 py-3 text-xs font-black uppercase text-gray-500 hover:bg-gray-50 rounded-2xl transition-all">Cancel</button>
            <button type="submit" className="flex-1 py-3 bg-indigo-600 text-white text-xs font-black uppercase rounded-2xl hover:bg-indigo-700 shadow-xl shadow-indigo-100 flex items-center justify-center group">Save Lead <ChevronRight className="w-4 h-4 ml-1 group-hover:translate-x-0.5 transition-transform" /></button>
          </div>
        </form>
      </motion.div>
    </motion.div>
  );
};

const LeadList: React.FC<LeadListProps> = ({ leads, onSelectLead, onAddLead, onUpdateLead }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingLead, setEditingLead] = useState<Lead | undefined>(undefined);

  const handleSave = (l: any) => {
    if (editingLead) onUpdateLead(l);
    else onAddLead(l);
    setIsModalOpen(false);
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-3xl border shadow-sm overflow-hidden">
        <div className="px-8 py-6 border-b flex items-center justify-between bg-gray-50/30">
          <h3 className="text-xl font-black text-gray-900 tracking-tight">Active Pipeline</h3>
          <button 
            onClick={() => { setEditingLead(undefined); setIsModalOpen(true); }}
            className="flex items-center px-5 py-2.5 bg-indigo-600 text-white text-xs font-black uppercase tracking-widest rounded-xl hover:bg-indigo-700 shadow-lg shadow-indigo-100 transition-all active:scale-95"
          >
            <Plus className="w-4 h-4 mr-2" /> Add Lead
          </button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-gray-50/50 text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">
              <tr>
                <th className="px-8 py-5">Lead Identity</th>
                <th className="px-8 py-5">Status</th>
                <th className="px-8 py-5">Pipeline Value</th>
                <th className="px-8 py-5">Interest</th>
                <th className="px-8 py-5 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {leads.map((lead) => (
                <tr key={lead.id} className="hover:bg-indigo-50/30 transition-colors group cursor-pointer" onClick={() => onSelectLead(lead)}>
                  <td className="px-8 py-5">
                    <div className="flex items-center">
                      <div className="w-10 h-10 rounded-2xl bg-indigo-600 flex items-center justify-center text-white font-black text-sm shadow-inner group-hover:scale-110 transition-transform">
                        {lead.name.split(' ').map(n => n[0]).join('')}
                      </div>
                      <div className="ml-4">
                        <p className="text-sm font-bold text-gray-900 leading-none mb-1">{lead.name}</p>
                        <p className="text-xs text-gray-400 font-medium">{lead.email}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-8 py-5">
                    <span className={`px-3 py-1 rounded-xl text-[10px] font-black uppercase tracking-wider ${STATUS_COLORS[lead.status]}`}>
                      {lead.status}
                    </span>
                  </td>
                  <td className="px-8 py-5">
                    <p className="text-sm font-black text-gray-900">${lead.value.toLocaleString()}</p>
                  </td>
                  <td className="px-8 py-5">
                    <p className="text-sm font-bold text-gray-700 truncate max-w-[200px]">{lead.propertyInterest}</p>
                    <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">{lead.location}</p>
                  </td>
                  <td className="px-8 py-5 text-right">
                    <button 
                      onClick={(e) => { e.stopPropagation(); setEditingLead(lead); setIsModalOpen(true); }}
                      className="p-2 text-gray-400 hover:text-indigo-600 hover:bg-white rounded-xl transition-all border border-transparent hover:border-indigo-100"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {leads.length === 0 && (
            <div className="py-20 text-center">
              <p className="text-gray-400 font-medium">No matching leads found.</p>
            </div>
          )}
        </div>
      </div>
      <AnimatePresence>
        {isModalOpen && <LeadModal lead={editingLead} onClose={() => setIsModalOpen(false)} onSave={handleSave} />}
      </AnimatePresence>
    </div>
  );
};

export default LeadList;
