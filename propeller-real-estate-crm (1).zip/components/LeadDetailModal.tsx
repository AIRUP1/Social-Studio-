
import React, { useState, useEffect } from 'react';
import { Lead, AIInsight, Task } from '../types.ts';
import { analyzeLead } from '../services/geminiService.ts';
import { STATUS_COLORS } from '../constants.tsx';
import { X, Mail, Phone, MapPin, Building, Calendar, Plus, Sparkles, MessageSquare, PhoneCall, FileText, ChevronRight, Zap, Loader2, Target, Activity, ShieldCheck } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface LeadDetailModalProps {
  lead: Lead;
  onClose: () => void;
  onAddTask: (task: Omit<Task, 'id'>) => void;
}

const LeadDetailModal: React.FC<LeadDetailModalProps> = ({ lead, onClose, onAddTask }) => {
  const [insight, setInsight] = useState<AIInsight | null>(null);
  const [loading, setLoading] = useState(false);
  const [generatingTask, setGeneratingTask] = useState(false);

  useEffect(() => {
    const fetchInsight = async () => {
      setLoading(true);
      try {
        const res = await analyzeLead(lead);
        setInsight(res);
      } catch (e) {
        console.error(e);
      }
      setLoading(false);
    };
    fetchInsight();
  }, [lead]);

  const handleExecuteAIStrategy = () => {
    if (!insight) return;
    setGeneratingTask(true);
    
    // Simulate complex AI planning then create the task
    setTimeout(() => {
      const newTask: Omit<Task, 'id'> = {
        leadId: lead.id,
        title: insight.suggestedAction,
        description: `AI recommended strategy based on analysis: ${insight.summary}`,
        dueDate: new Date().toISOString().split('T')[0],
        priority: insight.priorityScore > 75 ? 'High' : 'Medium',
        completed: false,
        recurrence: 'None',
        subtasks: []
      };
      onAddTask(newTask);
      setGeneratingTask(false);
      alert(`AI Task Created: ${insight.suggestedAction}`);
    }, 800);
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-gray-900/60 backdrop-blur-md z-50 flex items-center justify-center p-4 overflow-hidden"
    >
      <motion.div 
        initial={{ scale: 0.95, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        exit={{ scale: 0.95, y: 20 }}
        className="bg-white rounded-[40px] w-full max-w-6xl max-h-[90vh] overflow-hidden flex flex-col shadow-2xl border border-white/20"
      >
        {/* Header Section */}
        <div className="p-8 border-b bg-indigo-50/20 flex items-center justify-between">
          <div className="flex items-center space-x-6">
            <div className="w-16 h-16 rounded-[24px] bg-indigo-600 flex items-center justify-center text-white font-black text-2xl shadow-xl shadow-indigo-100">
              {lead.name.split(' ').map(n => n[0]).join('')}
            </div>
            <div>
              <div className="flex items-center space-x-3 mb-1">
                <h2 className="text-3xl font-black text-gray-900 tracking-tight">{lead.name}</h2>
                <span className={`px-3 py-1 rounded-xl text-[10px] font-black uppercase tracking-wider shadow-sm ${STATUS_COLORS[lead.status]}`}>
                  {lead.status}
                </span>
              </div>
              <div className="flex items-center space-x-4 text-sm text-gray-400 font-bold">
                <span className="flex items-center"><Mail className="w-4 h-4 mr-1 text-gray-300" /> {lead.email}</span>
                <span className="flex items-center"><Phone className="w-4 h-4 mr-1 text-gray-300" /> {lead.phone}</span>
              </div>
            </div>
          </div>
          <button onClick={onClose} className="p-4 hover:bg-gray-50 rounded-2xl text-gray-400 hover:text-gray-900 transition-all">
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Content Section */}
        <div className="flex-1 overflow-hidden flex">
          {/* Main Data Column */}
          <div className="flex-1 overflow-y-auto p-10 bg-white space-y-12 custom-scroll border-r border-gray-50">
            
            {/* NEW SECTION: AI EXECUTIVE SUMMARY */}
            <section className="space-y-6">
              <div className="flex items-center justify-between">
                <h3 className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] flex items-center">
                  <Sparkles className="w-3 h-3 mr-2 text-indigo-500 fill-current" />
                  AI Executive Summary
                </h3>
                {loading && <Loader2 className="w-4 h-4 text-indigo-600 animate-spin" />}
              </div>
              
              <AnimatePresence mode="wait">
                {insight ? (
                  <motion.div 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="relative overflow-hidden group"
                  >
                    <div className="p-8 bg-gray-900 rounded-[32px] text-white shadow-2xl relative z-10">
                      <div className="absolute top-0 right-0 p-6 opacity-10 pointer-events-none">
                        <Sparkles className="w-32 h-32 rotate-12" />
                      </div>
                      
                      <div className="flex flex-col md:flex-row gap-8 items-start">
                        <div className="flex-1 space-y-6">
                          <p className="text-xl font-bold leading-relaxed italic pr-4">
                            "{insight.summary}"
                          </p>
                          
                          <div className="flex flex-wrap gap-3">
                            <span className="flex items-center px-4 py-2 bg-white/5 border border-white/10 rounded-2xl text-[10px] font-black uppercase tracking-widest text-indigo-300">
                              <Target className="w-3 h-3 mr-2" />
                              Intent: {insight.priorityScore > 70 ? 'High' : 'Moderate'}
                            </span>
                            <span className="flex items-center px-4 py-2 bg-white/5 border border-white/10 rounded-2xl text-[10px] font-black uppercase tracking-widest text-emerald-300">
                              <ShieldCheck className="w-3 h-3 mr-2" />
                              Sentiment: {insight.sentiment}
                            </span>
                            <span className="flex items-center px-4 py-2 bg-white/5 border border-white/10 rounded-2xl text-[10px] font-black uppercase tracking-widest text-amber-300">
                              <Activity className="w-3 h-3 mr-2" />
                              Next: {insight.suggestedAction}
                            </span>
                          </div>
                        </div>

                        <div className="flex-shrink-0 flex flex-col items-center justify-center p-6 bg-white/5 rounded-[28px] border border-white/10 min-w-[140px]">
                           <div className="relative w-20 h-20 mb-3 flex items-center justify-center">
                              <svg className="w-full h-full transform -rotate-90">
                                <circle cx="40" cy="40" r="36" stroke="currentColor" strokeWidth="4" fill="transparent" className="text-white/10" />
                                <motion.circle 
                                  cx="40" cy="40" r="36" 
                                  stroke="currentColor" 
                                  strokeWidth="4" 
                                  fill="transparent" 
                                  className="text-indigo-400"
                                  strokeDasharray={226}
                                  initial={{ strokeDashoffset: 226 }}
                                  animate={{ strokeDashoffset: 226 - (226 * insight.priorityScore) / 100 }}
                                  transition={{ duration: 1.5, ease: "easeOut" }}
                                />
                              </svg>
                              <span className="absolute text-lg font-black">{insight.priorityScore}</span>
                           </div>
                           <p className="text-[9px] font-black uppercase tracking-widest text-gray-500">Lead Score</p>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                ) : loading ? (
                  <div className="p-12 bg-gray-50 rounded-[32px] border border-gray-100 flex flex-col items-center justify-center space-y-4 animate-pulse">
                    <Loader2 className="w-8 h-8 text-indigo-200 animate-spin" />
                    <p className="text-[10px] font-black uppercase tracking-widest text-gray-300">Synthesizing Profile...</p>
                  </div>
                ) : null}
              </AnimatePresence>
            </section>

            <section>
              <h3 className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] mb-6">Property DNA</h3>
              <div className="grid grid-cols-2 gap-6">
                <div className="p-6 bg-gray-50 rounded-[28px] border border-gray-100 flex items-start space-x-4">
                  <div className="p-3 bg-white rounded-2xl shadow-sm text-indigo-500"><Building className="w-5 h-5" /></div>
                  <div>
                    <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">Target Asset</p>
                    <p className="text-lg font-black text-gray-900 leading-tight">{lead.propertyInterest}</p>
                  </div>
                </div>
                <div className="p-6 bg-gray-50 rounded-[28px] border border-gray-100 flex items-start space-x-4">
                  <div className="p-3 bg-white rounded-2xl shadow-sm text-emerald-500"><Zap className="w-5 h-5" /></div>
                  <div>
                    <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">Investment Envelope</p>
                    <p className="text-lg font-black text-gray-900 leading-tight">${lead.value.toLocaleString()}</p>
                  </div>
                </div>
              </div>
            </section>

            <section>
              <div className="flex items-center justify-between mb-8">
                <h3 className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">Interaction Stream</h3>
                <button className="flex items-center text-[10px] font-black uppercase tracking-widest text-indigo-600 bg-indigo-50 px-4 py-2 rounded-xl hover:bg-indigo-100 transition-all">
                  <Plus className="w-4 h-4 mr-2" /> Log Touchpoint
                </button>
              </div>
              <div className="space-y-6">
                {lead.notes.map((note, i) => (
                  <div key={i} className="flex space-x-6 group">
                    <div className="flex flex-col items-center">
                      <div className="w-12 h-12 rounded-[18px] bg-white border-2 border-gray-50 flex items-center justify-center text-indigo-400 z-10 group-hover:bg-indigo-600 group-hover:text-white transition-all shadow-sm group-hover:shadow-indigo-200">
                        <MessageSquare className="w-5 h-5" />
                      </div>
                      {i < lead.notes.length - 1 && <div className="w-px h-full bg-gray-100 my-2"></div>}
                    </div>
                    <div className="flex-1 pb-4">
                      <div className="bg-white border border-gray-100 p-6 rounded-[28px] shadow-sm group-hover:shadow-md transition-all">
                        <div className="flex justify-between items-center mb-3">
                          <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Interaction Log • Step {lead.notes.length - i}</span>
                          <span className="text-[10px] font-bold text-emerald-500 bg-emerald-50 px-2 py-0.5 rounded-full">Synced</span>
                        </div>
                        <p className="text-sm text-gray-600 leading-relaxed font-bold">{note}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </section>
          </div>

          {/* AI Strategy Sidebar */}
          <div className="w-96 bg-gray-50/50 p-10 overflow-y-auto custom-scroll">
            <div className="bg-indigo-600 rounded-[40px] p-8 text-white shadow-2xl shadow-indigo-100 relative overflow-hidden mb-10">
              <div className="absolute top-0 right-0 p-4 opacity-10">
                <Sparkles className="w-24 h-24 rotate-12" />
              </div>
              <div className="relative z-10">
                <h3 className="text-xl font-black mb-8 flex items-center tracking-tight">
                  <Target className="w-6 h-6 mr-2 text-indigo-300" />
                  ML Strategy
                </h3>
                
                {insight ? (
                  <div className="space-y-8">
                    <div className="p-6 bg-white/10 rounded-[28px] border border-white/20">
                      <div className="flex justify-between items-end mb-4">
                        <span className="text-[10px] font-black uppercase text-indigo-200 tracking-widest">Closing Probability</span>
                        <span className="text-4xl font-black">{insight.priorityScore}%</span>
                      </div>
                      <div className="w-full bg-indigo-900/40 h-2 rounded-full overflow-hidden">
                        <motion.div initial={{ width: 0 }} animate={{ width: `${insight.priorityScore}%` }} transition={{ duration: 1.5 }} className="bg-white h-full rounded-full" />
                      </div>
                    </div>

                    <div className="bg-white text-indigo-950 p-6 rounded-[32px] shadow-xl shadow-indigo-900/10">
                      <p className="text-[10px] font-black uppercase text-indigo-400 tracking-widest mb-3">AI Recommendation</p>
                      <p className="text-sm font-bold leading-relaxed mb-6">"{insight.suggestedAction}"</p>
                      <button 
                        onClick={handleExecuteAIStrategy}
                        disabled={generatingTask}
                        className="w-full py-4 bg-indigo-600 text-white text-[10px] font-black rounded-2xl hover:bg-indigo-700 transition-all uppercase tracking-[0.2em] shadow-lg shadow-indigo-100 flex items-center justify-center disabled:opacity-50"
                      >
                        {generatingTask ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <ChevronRight className="w-4 h-4 mr-2" />}
                        {generatingTask ? 'Synthesizing...' : 'Deploy Smart Task'}
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="py-20 text-center opacity-50">
                    <Loader2 className="w-8 h-8 animate-spin mx-auto mb-4" />
                    <p className="text-xs font-bold uppercase tracking-widest text-center">Calibrating Model...</p>
                  </div>
                )}
              </div>
            </div>

            <div className="space-y-6">
              <h4 className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] px-2">Omnichannel Follow-up</h4>
              <div className="grid grid-cols-2 gap-4">
                {[
                  { icon: PhoneCall, label: 'Voice AI', color: 'text-emerald-600 bg-emerald-50 border-emerald-100' },
                  { icon: Mail, label: 'Smart Email', color: 'text-blue-600 bg-blue-50 border-blue-100' },
                  { icon: FileText, label: 'Gen Document', color: 'text-purple-600 bg-purple-50 border-purple-100' },
                  { icon: Calendar, label: 'Schedule', color: 'text-amber-600 bg-amber-50 border-amber-100' },
                ].map((btn, i) => (
                  <button key={i} className="flex flex-col items-center justify-center p-6 bg-white border border-gray-100 rounded-[28px] hover:shadow-xl hover:scale-[1.02] transition-all group">
                    <div className={`p-4 rounded-2xl mb-3 group-hover:scale-110 transition-transform ${btn.color} border`}>
                      <btn.icon className="w-5 h-5" />
                    </div>
                    <span className="text-[10px] font-black uppercase text-gray-900 tracking-widest">{btn.label}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
};

export default LeadDetailModal;
