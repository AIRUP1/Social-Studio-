
import React, { useState, useMemo, useRef, useEffect } from 'react';
import { Task, Lead, RecurrencePattern, Subtask } from '../types.ts';
import { CheckCircle2, Circle, Clock, AlertCircle, Plus, Search, Edit2, X, ChevronRight, ArrowUpDown, Trash2, CheckSquare, Square, User, Repeat, ListChecks, ChevronDown, ChevronUp, Settings2, Eye, ArrowDownWideNarrow, Check, MinusSquare } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface TaskViewProps {
  tasks: Task[];
  leads: Lead[];
  onToggleComplete: (id: string) => void;
  onAddTask: (task: Omit<Task, 'id'>) => void;
  onUpdateTask: (task: Task) => void;
  onBulkToggleComplete: (ids: string[], completed: boolean) => void;
  onDeleteTasks: (ids: string[]) => void;
}

interface TaskModalProps {
  task?: Task;
  leads: Lead[];
  onClose: () => void;
  onSave: (task: any) => void;
}

const TaskModal: React.FC<TaskModalProps> = ({ task, leads, onClose, onSave }) => {
  const [title, setTitle] = useState(task?.title || '');
  const [priority, setPriority] = useState<Task['priority']>(task?.priority || 'Medium');
  const [dueDate, setDueDate] = useState(task?.dueDate || new Date().toISOString().split('T')[0]);
  const [leadId, setLeadId] = useState(task?.leadId || (leads.length > 0 ? leads[0].id : ''));
  const [recurrence, setRecurrence] = useState<RecurrencePattern>(task?.recurrence || 'None');
  const [subtasks, setSubtasks] = useState<Subtask[]>(task?.subtasks || []);
  const [newSubtaskTitle, setNewSubtaskTitle] = useState('');

  const handleAddSubtask = () => {
    if (!newSubtaskTitle.trim()) return;
    const newSub: Subtask = {
      id: `s${Date.now()}`,
      title: newSubtaskTitle.trim(),
      completed: false
    };
    setSubtasks([...subtasks, newSub]);
    setNewSubtaskTitle('');
  };

  const toggleSubtask = (id: string) => {
    setSubtasks(subtasks.map(s => s.id === id ? { ...s, completed: !s.completed } : s));
  };

  const deleteSubtask = (id: string) => {
    setSubtasks(subtasks.filter(s => s.id !== id));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      ...(task || {}),
      title,
      priority,
      dueDate,
      leadId,
      recurrence,
      subtasks,
      completed: task?.completed || false,
      description: task?.description || ''
    });
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-gray-900/40 backdrop-blur-sm z-50 flex items-center justify-center p-4"
    >
      <motion.div
        initial={{ scale: 0.9, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        exit={{ scale: 0.9, y: 20 }}
        className="bg-white rounded-[32px] w-full max-w-lg overflow-hidden shadow-2xl border border-white/20 p-8 max-h-[90vh] flex flex-col"
      >
        <div className="flex items-center justify-between mb-8 flex-shrink-0">
          <h3 className="text-2xl font-black text-gray-900 tracking-tight">
            {task ? 'Edit Task' : 'Create Task'}
          </h3>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-xl transition-colors">
            <X className="w-5 h-5 text-gray-400" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6 overflow-y-auto pr-2 custom-scroll flex-1">
          <div className="space-y-2">
            <label className="text-[10px] font-black uppercase text-gray-400 tracking-widest px-1">Task Title</label>
            <input
              autoFocus
              required
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Call client for follow-up"
              className="w-full px-4 py-3 bg-gray-50 border-none rounded-2xl focus:ring-2 focus:ring-indigo-500 font-medium transition-all"
            />
          </div>

          <div className="space-y-2">
            <label className="text-[10px] font-black uppercase text-gray-400 tracking-widest px-1">Associate Lead</label>
            <select
              required
              value={leadId}
              onChange={(e) => setLeadId(e.target.value)}
              className="w-full px-4 py-3 bg-gray-50 border-none rounded-2xl focus:ring-2 focus:ring-indigo-500 font-medium transition-all appearance-none"
            >
              {leads.map(lead => (
                <option key={lead.id} value={lead.id}>{lead.name}</option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-[10px] font-black uppercase text-gray-400 tracking-widest px-1">Due Date</label>
              <input
                required
                type="date"
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                className="w-full px-4 py-3 bg-gray-50 border-none rounded-2xl focus:ring-2 focus:ring-indigo-500 font-medium transition-all"
              />
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-black uppercase text-gray-400 tracking-widest px-1">Repeat</label>
              <select
                value={recurrence}
                onChange={(e) => setRecurrence(e.target.value as RecurrencePattern)}
                className="w-full px-4 py-3 bg-gray-50 border-none rounded-2xl focus:ring-2 focus:ring-indigo-500 font-medium transition-all appearance-none"
              >
                <option value="None">No Repeat</option>
                <option value="Daily">Daily</option>
                <option value="Weekly">Weekly</option>
                <option value="Monthly">Monthly</option>
              </select>
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-[10px] font-black uppercase text-gray-400 tracking-widest px-1">Priority Level</label>
            <div className="grid grid-cols-3 gap-2">
              {(['Low', 'Medium', 'High'] as const).map((p) => (
                <button
                  key={p}
                  type="button"
                  onClick={() => setPriority(p)}
                  className={`py-2 text-xs font-bold rounded-xl border-2 transition-all ${
                    priority === p
                      ? 'bg-indigo-600 border-indigo-600 text-white shadow-lg shadow-indigo-100'
                      : 'bg-white border-gray-100 text-gray-500 hover:border-indigo-200'
                  }`}
                >
                  {p}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-4 pt-4 border-t border-gray-100">
            <div className="flex items-center justify-between">
              <label className="text-[10px] font-black uppercase text-gray-400 tracking-widest px-1 flex items-center">
                <ListChecks className="w-3 h-3 mr-1" /> Checklist / Subtasks
              </label>
              <span className="text-[10px] font-bold text-gray-400">
                {subtasks.filter(s => s.completed).length}/{subtasks.length} Completed
              </span>
            </div>
            <div className="space-y-2">
              <AnimatePresence mode="popLayout">
                {subtasks.map((s) => (
                  <motion.div 
                    layout
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    key={s.id} 
                    className="flex items-center group bg-gray-50/50 p-2 rounded-xl border border-gray-100/50"
                  >
                    <button type="button" onClick={() => toggleSubtask(s.id)} className="mr-3 text-gray-400 hover:text-indigo-500 transition-colors">
                      {s.completed ? <CheckCircle2 className="w-4 h-4 text-indigo-500" /> : <Circle className="w-4 h-4" />}
                    </button>
                    <span className={`text-sm font-medium flex-1 ${s.completed ? 'line-through text-gray-400' : 'text-gray-700'}`}>
                      {s.title}
                    </span>
                    <button type="button" onClick={() => deleteSubtask(s.id)} className="opacity-0 group-hover:opacity-100 p-1 text-gray-400 hover:text-rose-500 transition-all">
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
            <div className="flex space-x-2">
              <input
                type="text"
                value={newSubtaskTitle}
                onChange={(e) => setNewSubtaskTitle(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), handleAddSubtask())}
                placeholder="Add subtask..."
                className="flex-1 px-4 py-2 bg-gray-50 border-none rounded-xl focus:ring-2 focus:ring-indigo-500 text-sm font-medium"
              />
              <button 
                type="button" 
                onClick={handleAddSubtask}
                className="p-2 bg-indigo-50 text-indigo-600 rounded-xl hover:bg-indigo-100 transition-colors"
              >
                <Plus className="w-5 h-5" />
              </button>
            </div>
          </div>
        </form>

        <div className="pt-6 border-t border-gray-100 flex space-x-3 flex-shrink-0">
          <button
            type="button"
            onClick={onClose}
            className="flex-1 py-3 text-xs font-black uppercase text-gray-500 hover:bg-gray-50 rounded-2xl transition-all"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleSubmit}
            className="flex-1 py-3 bg-indigo-600 text-white text-xs font-black uppercase rounded-2xl hover:bg-indigo-700 shadow-xl shadow-indigo-100 transition-all flex items-center justify-center group"
          >
            {task ? 'Update Task' : 'Save Task'}
            <ChevronRight className="w-4 h-4 ml-1 group-hover:translate-x-0.5 transition-transform" />
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
};

type SortKey = 'dueDate' | 'priority' | 'title';

interface VisibleFields {
  lead: boolean;
  dueDate: boolean;
  priority: boolean;
  subtasks: boolean;
  recurrence: boolean;
}

const TaskView: React.FC<TaskViewProps> = ({ tasks, leads, onToggleComplete, onAddTask, onUpdateTask, onBulkToggleComplete, onDeleteTasks }) => {
  const [filter, setFilter] = useState<'all' | 'pending' | 'completed'>('all');
  const [search, setSearch] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | undefined>(undefined);
  const [sortBy, setSortBy] = useState<SortKey>('dueDate');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');
  
  const [isOptionsOpen, setIsOptionsOpen] = useState(false);
  const [isSortOpen, setIsSortOpen] = useState(false);
  
  const optionsRef = useRef<HTMLDivElement>(null);
  const sortRef = useRef<HTMLDivElement>(null);

  // Field visibility state
  const [visibleFields, setVisibleFields] = useState<VisibleFields>({
    lead: true,
    dueDate: true,
    priority: true,
    subtasks: true,
    recurrence: true,
  });
  
  const [expandedTaskIds, setExpandedTaskIds] = useState<Set<string>>(new Set());
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());

  const priorityWeight = { 'High': 3, 'Medium': 2, 'Low': 1 };

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (optionsRef.current && !optionsRef.current.contains(event.target as Node)) {
        setIsOptionsOpen(false);
      }
      if (sortRef.current && !sortRef.current.contains(event.target as Node)) {
        setIsSortOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const processedTasks = useMemo(() => {
    let result = tasks.filter(task => {
      const matchesFilter = 
        filter === 'all' || 
        (filter === 'pending' && !task.completed) || 
        (filter === 'completed' && task.completed);
      const matchesSearch = task.title.toLowerCase().includes(search.toLowerCase());
      return matchesFilter && matchesSearch;
    });

    return [...result].sort((a, b) => {
      let comparison = 0;
      if (sortBy === 'dueDate') {
        comparison = a.dueDate.localeCompare(b.dueDate);
      } else if (sortBy === 'priority') {
        comparison = priorityWeight[a.priority] - priorityWeight[b.priority];
      } else if (sortBy === 'title') {
        comparison = a.title.localeCompare(b.title);
      }

      if (comparison === 0 && sortBy === 'priority') {
          comparison = a.dueDate.localeCompare(b.dueDate);
      }

      return sortOrder === 'asc' ? comparison : -comparison;
    });
  }, [tasks, filter, search, sortBy, sortOrder]);

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'High': return 'text-rose-600 bg-rose-50 border-rose-100';
      case 'Medium': return 'text-amber-600 bg-amber-50 border-amber-100';
      default: return 'text-emerald-600 bg-emerald-50 border-emerald-100';
    }
  };

  const handleOpenAddModal = () => {
    setEditingTask(undefined);
    setIsModalOpen(true);
  };

  const handleOpenEditModal = (task: Task) => {
    setEditingTask(task);
    setIsModalOpen(true);
  };

  const handleSave = (taskData: any) => {
    if (editingTask) {
      onUpdateTask(taskData as Task);
    } else {
      onAddTask(taskData as Omit<Task, 'id'>);
    }
    setIsModalOpen(false);
  };

  const toggleSort = (key: SortKey) => {
    if (sortBy === key) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(key);
      setSortOrder('asc');
    }
  };

  const toggleSelection = (id: string) => {
    setSelectedIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const toggleSelectAll = () => {
    if (selectedIds.size === processedTasks.length && processedTasks.length > 0) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(processedTasks.map(t => t.id)));
    }
  };

  const toggleTaskExpansion = (id: string) => {
    setExpandedTaskIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const handleQuickToggleSubtask = (task: Task, subtaskId: string) => {
    const updatedSubtasks = task.subtasks.map(s => 
      s.id === subtaskId ? { ...s, completed: !s.completed } : s
    );
    onUpdateTask({ ...task, subtasks: updatedSubtasks });
  };

  const handleBulkComplete = (completed: boolean) => {
    onBulkToggleComplete(Array.from(selectedIds), completed);
    setSelectedIds(new Set());
  };

  const handleBulkDelete = () => {
    if (confirm(`Are you sure you want to delete ${selectedIds.size} tasks?`)) {
      onDeleteTasks(Array.from(selectedIds));
      setSelectedIds(new Set());
    }
  };

  const toggleField = (field: keyof VisibleFields) => {
    setVisibleFields(prev => ({ ...prev, [field]: !prev[field] }));
  };

  const isAllSelected = processedTasks.length > 0 && selectedIds.size === processedTasks.length;
  const isPartialSelected = selectedIds.size > 0 && !isAllSelected;

  const getLeadName = (id: string) => {
    return leads.find(l => l.id === id)?.name || 'Unknown Lead';
  };

  return (
    <div className="space-y-6 relative pb-24">
      <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-4 bg-white p-4 rounded-[28px] border shadow-sm border-gray-100">
        <div className="flex flex-col md:flex-row gap-4 flex-1">
          <div className="flex items-center space-x-3">
             <button 
                onClick={toggleSelectAll}
                className={`p-2.5 rounded-xl transition-all border ${isAllSelected || isPartialSelected ? 'text-indigo-600 bg-indigo-50 border-indigo-100' : 'text-gray-400 border-gray-50 hover:bg-gray-50'}`}
                title="Select All"
              >
                {isAllSelected ? <CheckSquare className="w-5 h-5" /> : isPartialSelected ? <MinusSquare className="w-5 h-5" /> : <Square className="w-5 h-5" />}
              </button>
            <div className="relative flex-1 min-w-[200px] md:w-64 lg:w-80">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input 
                type="text" 
                placeholder="Search tasks..." 
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 text-sm border-transparent bg-gray-50 rounded-xl focus:bg-white focus:ring-2 focus:ring-indigo-500 focus:outline-none transition-all font-medium"
              />
              <AnimatePresence>
                {selectedIds.size > 0 && (
                  <motion.div initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.8 }} className="absolute right-3 top-1/2 -translate-y-1/2 bg-indigo-600 text-white text-[10px] font-black px-2 py-0.5 rounded-full flex items-center">
                    {selectedIds.size} Selected
                    <button onClick={() => setSelectedIds(new Set())} className="ml-1.5 hover:text-indigo-200"><X className="w-3 h-3" /></button>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <div className="relative" ref={sortRef}>
              <button
                onClick={() => setIsSortOpen(!isSortOpen)}
                className={`flex items-center space-x-2 px-4 py-2.5 rounded-xl border transition-all text-sm font-bold ${isSortOpen ? 'bg-indigo-50 border-indigo-200 text-indigo-600' : 'bg-white border-gray-100 text-gray-600 hover:bg-gray-50'}`}
              >
                <ArrowDownWideNarrow className="w-4 h-4" />
                <span className="capitalize">{sortBy === 'dueDate' ? 'Due Date' : sortBy}</span>
                <ChevronDown className={`w-4 h-4 transition-transform ${isSortOpen ? 'rotate-180' : ''}`} />
              </button>
              <AnimatePresence>
                {isSortOpen && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.95, y: 10 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.95, y: 10 }}
                    className="absolute left-0 mt-2 w-56 bg-white rounded-2xl border shadow-xl z-30 overflow-hidden"
                  >
                    <div className="p-3 bg-gray-50 border-b">
                      <p className="text-[10px] font-black uppercase text-gray-400 tracking-widest flex items-center">
                        <ArrowDownWideNarrow className="w-3 h-3 mr-1" /> Sort Order
                      </p>
                    </div>
                    <div className="p-2 space-y-1">
                      {(['dueDate', 'priority', 'title'] as const).map((key) => (
                        <button
                          key={key}
                          onClick={() => { toggleSort(key); setIsSortOpen(false); }}
                          className={`w-full flex items-center justify-between px-3 py-2 text-xs font-bold rounded-xl transition-colors capitalize ${sortBy === key ? 'bg-indigo-50 text-indigo-600' : 'text-gray-700 hover:bg-gray-50'}`}
                        >
                          <div className="flex items-center">
                            {sortBy === key && <Check className="w-3 h-3 mr-2" />}
                            {key === 'dueDate' ? 'Due Date' : key}
                          </div>
                          {sortBy === key && (
                            <ArrowUpDown className={`w-3 h-3 transition-transform ${sortOrder === 'desc' ? 'rotate-180' : ''}`} />
                          )}
                        </button>
                      ))}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            <div className="relative" ref={optionsRef}>
              <button
                onClick={() => setIsOptionsOpen(!isOptionsOpen)}
                className={`p-2.5 rounded-xl border transition-all ${isOptionsOpen ? 'bg-indigo-50 border-indigo-200 text-indigo-600' : 'bg-white border-gray-100 text-gray-500 hover:bg-gray-50'}`}
                title="View Options"
              >
                <Settings2 className="w-5 h-5" />
              </button>
              <AnimatePresence>
                {isOptionsOpen && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.95, y: 10 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.95, y: 10 }}
                    className="absolute right-0 mt-2 w-56 bg-white rounded-2xl border shadow-xl z-30 overflow-hidden"
                  >
                    <div className="p-3 bg-gray-50 border-b">
                      <p className="text-[10px] font-black uppercase text-gray-400 tracking-widest flex items-center">
                        <Eye className="w-3 h-3 mr-1" /> Visible Columns
                      </p>
                    </div>
                    <div className="p-2 space-y-1">
                      {(Object.keys(visibleFields) as Array<keyof VisibleFields>).map((field) => (
                        <button
                          key={field}
                          onClick={() => toggleField(field)}
                          className="w-full flex items-center justify-between px-3 py-2 text-xs font-bold text-gray-700 hover:bg-gray-50 rounded-xl transition-colors capitalize"
                        >
                          {field === 'recurrence' ? 'Repeat' : field === 'subtasks' ? 'Checklist' : field}
                          <div className={`w-10 h-5 rounded-full transition-colors relative ${visibleFields[field] ? 'bg-indigo-600' : 'bg-gray-200'}`}>
                            <div className={`absolute top-1 w-3 h-3 bg-white rounded-full transition-all ${visibleFields[field] ? 'left-6' : 'left-1'}`} />
                          </div>
                        </button>
                      ))}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <div className="flex bg-gray-100 p-1 rounded-xl">
            {(['all', 'pending', 'completed'] as const).map((f) => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={`px-4 py-2 text-xs font-black uppercase tracking-widest rounded-lg transition-all ${
                  filter === f ? 'bg-white text-indigo-600 shadow-sm' : 'text-gray-500 hover:text-gray-700'
                }`}
              >
                {f}
              </button>
            ))}
          </div>
          <button 
            onClick={handleOpenAddModal}
            className="p-2.5 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 shadow-xl shadow-indigo-100 transition-all active:scale-95"
          >
            <Plus className="w-5 h-5" />
          </button>
        </div>
      </div>

      <div className="grid gap-4">
        <AnimatePresence mode='popLayout'>
          {processedTasks.length > 0 ? (
            processedTasks.map((task) => {
              const isSelected = selectedIds.has(task.id);
              const isExpanded = expandedTaskIds.has(task.id);
              const completedSubtasks = task.subtasks?.filter(s => s.completed).length || 0;
              const totalSubtasks = task.subtasks?.length || 0;
              const hasSubtasks = totalSubtasks > 0;

              return (
                <motion.div
                  layout
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  key={task.id}
                  className={`group flex flex-col overflow-hidden rounded-[28px] border transition-all duration-300 ${
                    isSelected ? 'bg-indigo-50/60 border-indigo-200 shadow-lg shadow-indigo-100/50 ring-2 ring-indigo-500/10 translate-x-1' : 'bg-white border-gray-100 shadow-sm hover:border-indigo-100'
                  } ${task.completed ? 'opacity-60 grayscale-[0.3]' : ''}`}
                >
                  <div className="flex items-center p-5">
                    <div className="flex items-center mr-4">
                      <button 
                        onClick={(e) => { e.stopPropagation(); toggleSelection(task.id); }}
                        className={`mr-4 p-2 rounded-xl transition-all ${isSelected ? 'text-indigo-600 bg-white shadow-sm ring-1 ring-indigo-100' : 'text-gray-200 hover:text-indigo-300 hover:bg-indigo-50'}`}
                      >
                        {isSelected ? <CheckSquare className="w-5 h-5" /> : <Square className="w-5 h-5" />}
                      </button>
                      <button 
                        onClick={(e) => { e.stopPropagation(); onToggleComplete(task.id); }}
                        className="flex-shrink-0 transition-transform active:scale-75"
                      >
                        {task.completed ? (
                          <CheckCircle2 className="w-7 h-7 text-indigo-500" />
                        ) : (
                          <Circle className="w-7 h-7 text-gray-200 hover:text-indigo-400" />
                        )}
                      </button>
                    </div>
                    <div className="flex-1 min-w-0" onClick={() => (hasSubtasks && visibleFields.subtasks) ? toggleTaskExpansion(task.id) : toggleSelection(task.id)}>
                      <div className="flex items-center">
                        <h4 className={`text-base font-bold text-gray-900 cursor-pointer select-none flex items-center ${task.completed ? 'line-through text-gray-400' : ''}`}>
                          {task.title}
                          {visibleFields.recurrence && task.recurrence && task.recurrence !== 'None' && (
                            <span className="ml-2 text-indigo-400" title={`Repeats ${task.recurrence}`}>
                              <Repeat className="w-3.5 h-3.5" />
                            </span>
                          )}
                        </h4>
                        {hasSubtasks && visibleFields.subtasks && (
                          <button 
                            onClick={(e) => { e.stopPropagation(); toggleTaskExpansion(task.id); }}
                            className={`ml-2 p-1 rounded-lg transition-colors ${isExpanded ? 'bg-indigo-50 text-indigo-600' : 'text-gray-300 hover:bg-gray-100'}`}
                          >
                            {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                          </button>
                        )}
                      </div>
                      <div className="flex flex-wrap items-center mt-2 gap-x-4 gap-y-1.5 text-xs text-gray-500 font-bold">
                        {visibleFields.dueDate && (
                          <span className="flex items-center bg-gray-50 px-2 py-0.5 rounded-lg">
                            <Clock className="w-3 h-3 mr-1.5 text-gray-400" />
                            {task.dueDate}
                          </span>
                        )}
                        {visibleFields.priority && (
                          <span className={`px-2 py-0.5 rounded-lg border font-black uppercase tracking-wider text-[9px] ${getPriorityColor(task.priority)}`}>
                            {task.priority}
                          </span>
                        )}
                        {visibleFields.lead && (
                          <span className="flex items-center text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-lg border border-indigo-100 text-[9px] font-black uppercase tracking-wider">
                            <User className="w-2.5 h-2.5 mr-1.5" />
                            {getLeadName(task.leadId)}
                          </span>
                        )}
                        {visibleFields.subtasks && hasSubtasks && (
                          <span className={`flex items-center px-2 py-0.5 rounded-lg border text-[9px] font-black uppercase tracking-wider ${completedSubtasks === totalSubtasks ? 'bg-emerald-50 text-emerald-600 border-emerald-100' : 'bg-gray-50 text-gray-500 border-gray-100'}`}>
                            <ListChecks className="w-2.5 h-2.5 mr-1.5" />
                            {completedSubtasks}/{totalSubtasks}
                          </span>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center space-x-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button 
                        onClick={(e) => { e.stopPropagation(); handleOpenEditModal(task); }}
                        className="p-3 text-gray-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-xl transition-all"
                      >
                        <Edit2 className="w-4.5 h-4.5" />
                      </button>
                    </div>
                  </div>

                  <AnimatePresence>
                    {isExpanded && hasSubtasks && visibleFields.subtasks && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        className="overflow-hidden border-t border-gray-50 bg-gray-50/40"
                      >
                        <div className="px-20 py-4 space-y-2.5">
                          {task.subtasks.map((sub) => (
                            <div key={sub.id} className="flex items-center space-x-3 group/sub">
                              <button 
                                onClick={() => handleQuickToggleSubtask(task, sub.id)}
                                className="flex-shrink-0 transition-all hover:scale-125"
                              >
                                {sub.completed ? (
                                  <CheckCircle2 className="w-4.5 h-4.5 text-emerald-500" />
                                ) : (
                                  <Circle className="w-4.5 h-4.5 text-gray-300" />
                                )}
                              </button>
                              <span className={`text-sm font-semibold tracking-tight ${sub.completed ? 'line-through text-gray-400' : 'text-gray-600'}`}>
                                {sub.title}
                              </span>
                            </div>
                          ))}
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </motion.div>
              );
            })
          ) : (
            <div className="text-center py-24 bg-gray-50 rounded-[40px] border-2 border-dashed border-gray-200">
              <div className="w-20 h-20 bg-white rounded-3xl shadow-sm flex items-center justify-center mx-auto mb-6 text-gray-200">
                <AlertCircle className="w-10 h-10" />
              </div>
              <h3 className="text-xl font-black text-gray-900 tracking-tight">Zero tasks on deck</h3>
              <p className="text-gray-400 font-bold uppercase text-[10px] tracking-widest mt-2">Adjust search or add items to your list</p>
            </div>
          )}
        </AnimatePresence>
      </div>

      <AnimatePresence>
        {selectedIds.size > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 100, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 100, scale: 0.9 }}
            className="fixed bottom-10 left-1/2 -translate-x-1/2 z-40 w-fit"
          >
            <div className="bg-gray-900/95 backdrop-blur-xl text-white px-8 py-5 rounded-[32px] shadow-2xl shadow-indigo-900/30 flex items-center space-x-8 border border-white/10">
              <div className="flex items-center space-x-4 border-r border-white/10 pr-8">
                <div className="bg-indigo-600 text-white w-9 h-9 flex items-center justify-center rounded-2xl text-sm font-black shadow-lg shadow-indigo-500/50">
                  {selectedIds.size}
                </div>
                <div className="flex flex-col">
                  <span className="text-[10px] font-black uppercase tracking-widest text-indigo-400 leading-none mb-1">Queue Control</span>
                  <span className="text-xs font-bold text-gray-300 whitespace-nowrap">Selected items ready</span>
                </div>
              </div>
              
              <div className="flex items-center space-x-3">
                <button 
                  onClick={() => handleBulkComplete(true)}
                  className="group flex items-center px-5 py-3 bg-white/10 hover:bg-white/20 rounded-2xl transition-all text-sm font-black uppercase tracking-widest text-indigo-300 hover:text-white"
                >
                  <CheckCircle2 className="w-5 h-5 mr-3" />
                  Complete
                </button>
                <button 
                  onClick={handleBulkDelete}
                  className="group flex items-center px-5 py-3 bg-rose-500/10 hover:bg-rose-500 rounded-2xl transition-all text-sm font-black uppercase tracking-widest text-rose-400 hover:text-white"
                >
                  <Trash2 className="w-5 h-5 mr-3" />
                  Destroy
                </button>
              </div>

              <div className="w-px h-8 bg-white/10 mx-2"></div>

              <button 
                onClick={() => setSelectedIds(new Set())}
                className="p-3 bg-white/5 hover:bg-white/10 rounded-2xl transition-all text-gray-500 hover:text-white"
                title="Cancel selection"
              >
                <X className="w-6 h-6" />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {isModalOpen && (
          <TaskModal 
            task={editingTask} 
            leads={leads}
            onClose={() => setIsModalOpen(false)} 
            onSave={handleSave} 
          />
        )}
      </AnimatePresence>
    </div>
  );
};

export default TaskView;
