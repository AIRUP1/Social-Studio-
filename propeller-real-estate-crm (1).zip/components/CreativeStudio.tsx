
import React, { useState, useRef } from 'react';
import { GoogleGenAI } from "@google/genai";
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Clapperboard, 
  Image as ImageIcon, 
  Sparkles, 
  Loader2, 
  Download, 
  Video, 
  ArrowRight, 
  Settings2, 
  Plus, 
  Key,
  Info,
  ChevronRight,
  MonitorPlay,
  PlayCircle
} from 'lucide-react';
import { MediaAsset } from '../types.ts';

const CreativeStudio: React.FC = () => {
  const [prompt, setPrompt] = useState('');
  const [generating, setGenerating] = useState(false);
  const [mode, setMode] = useState<'video' | 'image'>('video');
  const [assets, setAssets] = useState<MediaAsset[]>([]);
  const [statusMessage, setStatusMessage] = useState('');
  const [base64Image, setBase64Image] = useState<string | null>(null);
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setBase64Image(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const generateVideo = async () => {
    if (!prompt.trim()) return;

    // Veo protocol: Check key selection
    // @ts-ignore
    const hasKey = await window.aistudio.hasSelectedApiKey();
    if (!hasKey) {
      // @ts-ignore
      await window.aistudio.openSelectKey();
      // Proceed after triggering (assuming success as per race condition rule)
    }

    setGenerating(true);
    setStatusMessage('Initializing Cinematic Engine...');
    
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      let operation = await ai.models.generateVideos({
        model: 'veo-3.1-fast-generate-preview',
        prompt: `Real estate marketing video: ${prompt}. Professional cinematography, high-end architecture lighting, 4k detail.`,
        image: base64Image ? {
          imageBytes: base64Image.split(',')[1],
          mimeType: base64Image.split(';')[0].split(':')[1]
        } : undefined,
        config: {
          numberOfVideos: 1,
          resolution: '1080p',
          aspectRatio: '16:9'
        }
      });

      const messages = [
        "Synthesizing spatial geometry...",
        "Rendering cinematic lighting...",
        "Applying architectural textures...",
        "Finalizing high-fidelity frames...",
        "Polishing visual transitions..."
      ];

      let msgIdx = 0;
      while (!operation.done) {
        setStatusMessage(messages[msgIdx % messages.length]);
        msgIdx++;
        await new Promise(resolve => setTimeout(resolve, 8000));
        operation = await ai.operations.getVideosOperation({ operation: operation });
      }

      const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
      if (downloadLink) {
        const fetchRes = await fetch(`${downloadLink}&key=${process.env.API_KEY}`);
        const videoBlob = await fetchRes.blob();
        const videoUrl = URL.createObjectURL(videoBlob);
        
        const newAsset: MediaAsset = {
          id: `vid-${Date.now()}`,
          type: 'video',
          url: videoUrl,
          prompt,
          createdAt: new Date().toLocaleTimeString()
        };
        setAssets(prev => [newAsset, ...prev]);
      }
    } catch (error) {
      console.error("Video Generation Error:", error);
      alert("Video generation failed. Ensure your selected API key has Veo billing enabled.");
    } finally {
      setGenerating(false);
      setStatusMessage('');
      setBase64Image(null);
    }
  };

  const generateImage = async () => {
    if (!prompt.trim()) return;
    setGenerating(true);
    setStatusMessage('Visualizing Luxury Render...');

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: {
          parts: [{ text: `High-end real estate architectural visualization, luxury property, professional photography, sunset lighting, 8k resolution, photorealistic: ${prompt}` }]
        },
        config: {
          imageConfig: { aspectRatio: "16:9" }
        }
      });

      const imagePart = response.candidates?.[0]?.content?.parts.find(p => p.inlineData);
      if (imagePart?.inlineData) {
        const imageUrl = `data:${imagePart.inlineData.mimeType};base64,${imagePart.inlineData.data}`;
        const newAsset: MediaAsset = {
          id: `img-${Date.now()}`,
          type: 'image',
          url: imageUrl,
          prompt,
          createdAt: new Date().toLocaleTimeString()
        };
        setAssets(prev => [newAsset, ...prev]);
      }
    } catch (error) {
      console.error("Image Generation Error:", error);
    } finally {
      setGenerating(false);
      setStatusMessage('');
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 h-full">
      {/* Control Panel */}
      <div className="lg:col-span-5 flex flex-col space-y-6">
        <div className="bg-gray-900 rounded-[40px] p-8 text-white shadow-2xl relative overflow-hidden border border-white/5">
          <div className="absolute top-0 right-0 p-4 opacity-10">
            <Sparkles className="w-24 h-24 rotate-12" />
          </div>
          
          <div className="relative z-10 space-y-8">
            <div className="flex items-center space-x-2 bg-white/5 w-fit px-4 py-2 rounded-2xl border border-white/10">
              <Sparkles className="w-4 h-4 text-indigo-400 fill-current" />
              <span className="text-[10px] font-black uppercase tracking-[0.2em] text-indigo-200">AI Media Studio</span>
            </div>

            <div>
              <h2 className="text-3xl font-black tracking-tight mb-2">Creative Engine</h2>
              <p className="text-gray-400 text-sm font-medium">Generate cinematic content for your listings.</p>
            </div>

            <div className="grid grid-cols-2 gap-3 p-1 bg-white/5 rounded-2xl border border-white/10">
              <button 
                onClick={() => setMode('video')}
                className={`flex items-center justify-center space-x-2 py-3 rounded-xl transition-all text-xs font-black uppercase tracking-widest ${mode === 'video' ? 'bg-indigo-600 text-white shadow-lg' : 'text-gray-400 hover:text-white'}`}
              >
                <MonitorPlay className="w-4 h-4" />
                <span>Trailer</span>
              </button>
              <button 
                onClick={() => setMode('image')}
                className={`flex items-center justify-center space-x-2 py-3 rounded-xl transition-all text-xs font-black uppercase tracking-widest ${mode === 'image' ? 'bg-indigo-600 text-white shadow-lg' : 'text-gray-400 hover:text-white'}`}
              >
                <ImageIcon className="w-4 h-4" />
                <span>Render</span>
              </button>
            </div>

            <div className="space-y-4">
              <label className="text-[10px] font-black uppercase tracking-widest text-gray-500 block px-2">Creative Prompt</label>
              <textarea 
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder={mode === 'video' ? "e.g. A slow cinematic sweep of a modern beachfront villa at sunset..." : "e.g. Master bedroom with floor-to-ceiling windows overlooking city skyline..."}
                className="w-full bg-white/5 border border-white/10 rounded-3xl p-5 text-sm font-medium focus:ring-2 focus:ring-indigo-500 focus:outline-none min-h-[140px] resize-none transition-all placeholder:text-gray-600"
              />
            </div>

            {mode === 'video' && (
              <div className="space-y-4">
                <label className="text-[10px] font-black uppercase tracking-widest text-gray-500 block px-2">Reference Image (Optional)</label>
                <div 
                  onClick={() => fileInputRef.current?.click()}
                  className={`border-2 border-dashed rounded-3xl p-6 flex flex-col items-center justify-center cursor-pointer transition-all ${base64Image ? 'border-indigo-500 bg-indigo-500/10' : 'border-white/10 hover:border-white/20 bg-white/5'}`}
                >
                  <input type="file" ref={fileInputRef} hidden accept="image/*" onChange={handleFileChange} />
                  {base64Image ? (
                    <div className="flex items-center space-x-3">
                      <img src={base64Image} className="w-12 h-12 rounded-lg object-cover" />
                      <span className="text-xs font-bold text-indigo-300">Image Locked as Start Frame</span>
                    </div>
                  ) : (
                    <>
                      <Plus className="w-6 h-6 text-gray-500 mb-2" />
                      <span className="text-xs font-bold text-gray-400">Photo-to-Video Mode</span>
                    </>
                  )}
                </div>
              </div>
            )}

            <button 
              onClick={mode === 'video' ? generateVideo : generateImage}
              disabled={generating || !prompt.trim()}
              className="w-full py-5 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed rounded-[28px] text-xs font-black uppercase tracking-[0.2em] shadow-2xl shadow-indigo-900/50 flex items-center justify-center transition-all active:scale-95"
            >
              {generating ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin mr-3" />
                  {statusMessage}
                </>
              ) : (
                <>
                  <Sparkles className="w-5 h-5 mr-3" />
                  Generate {mode}
                </>
              )}
            </button>

            <div className="flex items-start space-x-3 p-4 bg-amber-500/10 rounded-2xl border border-amber-500/20">
              <Info className="w-4 h-4 text-amber-500 flex-shrink-0 mt-0.5" />
              <p className="text-[10px] font-bold text-amber-200/80 leading-relaxed">
                {mode === 'video' 
                  ? "Veo high-fidelity generation takes ~1-3 minutes. High-speed fiber connection recommended for 1080p preview."
                  : "Image generation is instantaneous. Use descriptive keywords like 'soft lighting' or 'minimalist'."}
              </p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-[32px] p-8 border shadow-sm">
          <h3 className="text-[10px] font-black uppercase tracking-widest text-gray-400 mb-4 flex items-center">
            <Key className="w-3 h-3 mr-2" /> Billing Information
          </h3>
          <p className="text-xs font-medium text-gray-500 leading-relaxed">
            Video generation uses Veo models. You must select a paid project via <a href="https://ai.google.dev/gemini-api/docs/billing" target="_blank" className="text-indigo-600 font-bold hover:underline">Google Cloud Billing</a> to avoid usage limits.
          </p>
        </div>
      </div>

      {/* Media Gallery */}
      <div className="lg:col-span-7 flex flex-col h-full">
        <div className="flex items-center justify-between mb-8 px-2">
          <h3 className="text-xl font-black tracking-tight flex items-center">
            <PlayCircle className="w-5 h-5 mr-3 text-indigo-500" />
            Project Assets
          </h3>
          <span className="text-[10px] font-black uppercase bg-gray-100 px-3 py-1 rounded-full text-gray-500">
            {assets.length} items
          </span>
        </div>

        <div className="flex-1 overflow-y-auto custom-scroll pr-2 space-y-6">
          <AnimatePresence mode="popLayout">
            {assets.length === 0 ? (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="h-full flex flex-col items-center justify-center py-20 bg-gray-50 rounded-[40px] border-2 border-dashed border-gray-200"
              >
                <div className="w-20 h-20 bg-white rounded-3xl shadow-sm flex items-center justify-center mb-6">
                  <Clapperboard className="w-10 h-10 text-gray-200" />
                </div>
                <p className="text-sm font-bold text-gray-400 uppercase tracking-widest">Gallery Empty</p>
                <p className="text-xs text-gray-400 mt-2">Generate your first marketing asset</p>
              </motion.div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {assets.map((asset) => (
                  <motion.div 
                    layout
                    initial={{ opacity: 0, scale: 0.9, y: 20 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.9 }}
                    key={asset.id}
                    className="bg-white rounded-[32px] border shadow-sm overflow-hidden group hover:shadow-xl hover:scale-[1.02] transition-all"
                  >
                    <div className="aspect-video relative bg-black overflow-hidden">
                      {asset.type === 'video' ? (
                        <video 
                          src={asset.url} 
                          controls 
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <img 
                          src={asset.url} 
                          className="w-full h-full object-cover"
                        />
                      )}
                      <div className="absolute top-4 left-4">
                        <span className="px-3 py-1 bg-white/20 backdrop-blur-md border border-white/20 text-white text-[9px] font-black uppercase tracking-widest rounded-lg">
                          {asset.type}
                        </span>
                      </div>
                    </div>
                    <div className="p-6">
                      <p className="text-xs font-bold text-gray-700 line-clamp-2 mb-4 leading-relaxed italic">
                        "{asset.prompt}"
                      </p>
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-black uppercase text-gray-400 tracking-widest">
                          {asset.createdAt}
                        </span>
                        <a 
                          href={asset.url} 
                          download={`propeller-${asset.id}`}
                          className="p-3 bg-indigo-50 text-indigo-600 rounded-2xl hover:bg-indigo-600 hover:text-white transition-all shadow-sm"
                        >
                          <Download className="w-4 h-4" />
                        </a>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
};

export default CreativeStudio;
