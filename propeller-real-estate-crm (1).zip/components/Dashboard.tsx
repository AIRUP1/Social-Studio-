
import React from 'react';
import { Lead, Task } from '../types.ts';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell, PieChart, Pie } from 'recharts';
import { TrendingUp, Users, Calendar, ArrowUpRight, Clock } from 'lucide-react';
import { motion } from 'framer-motion';

interface DashboardProps {
  leads: Lead[];
  tasks: Task[];
  onSelectLead: (lead: Lead) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ leads, tasks, onSelectLead }) => {
  const totalValue = leads.reduce((acc, curr) => acc + curr.value, 0);
  const pendingTasks = tasks.filter(t => !t.completed).length;
  
  const statusData = [
    { name: 'New', count: leads.filter(l => l.status === 'New').length },
    { name: 'Contacted', count: leads.filter(l => l.status === 'Contacted').length },
    { name: 'Qualified', count: leads.filter(l => l.status === 'Qualified').length },
    { name: 'Negotiation', count: leads.filter(l => l.status === 'Negotiation').length },
    { name: 'Closed', count: leads.filter(l => l.status === 'Closed').length },
  ];

  const valueData = leads.map(l => ({ name: l.name, value: l.value }));
  const COLORS = ['#6366f1', '#818cf8', '#a5b4fc', '#c7d2fe', '#e0e7ff'];

  // Prioritize urgent tasks for Dashboard
  const sortedPendingTasks = [...tasks]
    .filter(t => !t.completed)
    .sort((a, b) => a.dueDate.localeCompare(b.dueDate));

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: { staggerChildren: 0.1 }
    }
  };

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 }
  };

  return (
    <motion.div variants={container} initial="hidden" animate="show" className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {[
          { label: 'Pipeline Value', val: `$${totalValue.toLocaleString()}`, icon: TrendingUp, color: 'text-indigo-600', trend: '+12.5%' },
          { label: 'Active Leads', val: leads.length, icon: Users, color: 'text-blue-600', trend: '4 new' },
          { label: 'Tasks Due', val: pendingTasks, icon: Calendar, color: 'text-amber-600', trend: '2 high' },
        ].map((stat, i) => (
          <motion.div key={i} variants={item} className="bg-white p-6 rounded-3xl border shadow-sm group hover:shadow-md transition-all">
            <div className="flex justify-between items-start mb-4">
              <div className={`p-3 rounded-2xl bg-gray-50 group-hover:scale-110 transition-transform ${stat.color}`}>
                <stat.icon className="w-6 h-6" />
              </div>
              <span className="text-xs font-bold text-emerald-600 bg-emerald-50 px-2 py-1 rounded-lg flex items-center">
                <ArrowUpRight className="w-3 h-3 mr-1" />
                {stat.trend}
              </span>
            </div>
            <p className="text-sm font-semibold text-gray-500 uppercase tracking-wider">{stat.label}</p>
            <p className="text-3xl font-black text-gray-900 mt-1">{stat.val}</p>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        <motion.div variants={item} className="lg:col-span-3 bg-white p-6 rounded-3xl border shadow-sm">
          <h3 className="text-lg font-bold text-gray-900 mb-6 flex items-center">
            <TrendingUp className="w-5 h-5 mr-2 text-indigo-500" />
            Conversion Funnel
          </h3>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={statusData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f3f4f6" />
                <XAxis dataKey="name" fontSize={12} tickLine={false} axisLine={false} tick={{fill: '#9ca3af'}} />
                <YAxis fontSize={12} tickLine={false} axisLine={false} tick={{fill: '#9ca3af'}} />
                <Tooltip cursor={{fill: '#f9fafb'}} contentStyle={{borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)'}} />
                <Bar dataKey="count" radius={[8, 8, 0, 0]} barSize={40}>
                  {statusData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </motion.div>

        <motion.div variants={item} className="lg:col-span-2 bg-white rounded-3xl border shadow-sm overflow-hidden flex flex-col">
          <div className="px-6 py-5 border-b border-gray-50 flex items-center justify-between">
            <h3 className="text-lg font-bold text-gray-900 flex items-center">
              <Clock className="w-5 h-5 mr-2 text-amber-500" />
              Immediate Actions
            </h3>
            <span className="text-xs font-bold bg-indigo-50 text-indigo-600 px-2 py-1 rounded-lg">
              {pendingTasks} Total
            </span>
          </div>
          <div className="flex-1 overflow-y-auto divide-y divide-gray-50">
            {sortedPendingTasks.length > 0 ? (
              sortedPendingTasks.slice(0, 6).map(task => {
                const lead = leads.find(l => l.id === task.leadId);
                return (
                  <div key={task.id} className="px-6 py-4 hover:bg-indigo-50/30 transition-colors group cursor-pointer" onClick={() => lead && onSelectLead(lead)}>
                    <div className="flex items-center justify-between mb-1">
                      <p className="text-sm font-bold text-gray-900 group-hover:text-indigo-600 transition-colors">{task.title}</p>
                      <span className={`w-2 h-2 rounded-full ${task.priority === 'High' ? 'bg-rose-500 animate-pulse' : 'bg-amber-400'}`} />
                    </div>
                    <div className="flex justify-between items-center text-xs">
                      <p className="text-gray-500 italic">For: {lead?.name}</p>
                      <p className="text-gray-400">{task.dueDate}</p>
                    </div>
                  </div>
                );
              })
            ) : (
              <div className="p-10 text-center">
                <p className="text-gray-400 text-sm">All caught up! 🎉</p>
              </div>
            )}
          </div>
          <button className="w-full py-4 text-xs font-bold text-indigo-600 hover:bg-gray-50 transition-colors uppercase tracking-widest">
            View All Tasks
          </button>
        </motion.div>
      </div>
    </motion.div>
  );
};

export default Dashboard;
