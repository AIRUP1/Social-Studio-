
import React, { useState } from 'react';
import { GoogleGenAI } from "@google/genai";
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Globe, 
  Search, 
  Loader2, 
  ChevronRight, 
  ExternalLink, 
  Plus, 
  Info, 
  Zap, 
  Terminal,
  Building2,
  MapPin,
  DollarSign,
  UserPlus
} from 'lucide-react';
import { ScrapedListing, Lead } from '../types.ts';

interface WebProspectorProps {
  onImportLead: (lead: Omit<Lead, 'id'>) => void;
}

const WebProspector: React.FC<WebProspectorProps> = ({ onImportLead }) => {
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<ScrapedListing[]>([]);
  const [groundingChunks, setGroundingChunks] = useState<any[]>([]);
  const [status, setStatus] = useState('');

  const handleScrape = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;

    setLoading(true);
    setResults([]);
    setGroundingChunks([]);
    setStatus('Initializing Web Crawler...');

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      const prompt = `Act as a real estate data scraper. Extract detailed property listing information for the following request: "${query}". 
      If a URL is provided, extract data from that specific page. If a general search is provided, find top active listings.
      Return the data in a clear, structured list format including: Address, Price, Key Details (beds/baths/sqft), and Agent Name if available.`;

      setStatus('Scanning Real Estate Networks...');
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
        config: {
          tools: [{ googleSearch: {} }],
        },
      });

      setStatus('Parsing Data Structures...');
      
      // Extract grounding links
      const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
      setGroundingChunks(chunks);

      // Parse the text output into listings (simplified parsing for demo)
      // In a production app, we would use responseSchema for JSON, but googleSearch tools 
      // often work better with freeform text then a second pass for JSON parsing.
      const text = response.text;
      
      // We'll simulate structured parsing from the text response
      const lines = text.split('\n').filter(l => l.trim().length > 0);
      const mockListings: ScrapedListing[] = [];
      
      // Basic extraction logic: looking for lines that look like addresses or prices
      let currentListing: Partial<ScrapedListing> = {};
      
      lines.forEach(line => {
        if (line.match(/\d+.*[A-Z]{2}/)) { // Looks like an address
          if (currentListing.address) mockListings.push(currentListing as ScrapedListing);
          currentListing = { address: line.replace(/[*\-#]/g, '').trim(), sourceUrl: chunks[0]?.web?.uri || '#' };
        } else if (line.includes('$')) {
          currentListing.price = line.trim();
        } else if (line.length > 20) {
          currentListing.details = (currentListing.details || '') + ' ' + line.trim();
        }
      });
      if (currentListing.address) mockListings.push(currentListing as ScrapedListing);

      setResults(mockListings.slice(0, 5));
    } catch (error) {
      console.error("Scraping Error:", error);
    } finally {
      setLoading(false);
      setStatus('');
    }
  };

  const handleImport = (listing: ScrapedListing) => {
    const newLead: Omit<Lead, 'id'> = {
      name: listing.agentName || 'Interested Party',
      email: 'prospect@example.com',
      phone: 'N/A',
      status: 'New',
      value: parseInt(listing.price.replace(/[^0-9]/g, '')) || 0,
      propertyInterest: listing.address,
      location: listing.address.split(',').pop()?.trim() || 'Unknown',
      notes: [`Source: ${listing.sourceUrl}`, `Details: ${listing.details}`],
      lastInteraction: new Date().toISOString().split('T')[0],
      createdAt: new Date().toISOString().split('T')[0],
    };
    onImportLead(newLead);
    alert(`Imported listing: ${listing.address}`);
  };

  return (
    <div className="space-y-8">
      {/* Scraper Control */}
      <div className="bg-white rounded-[40px] p-10 border shadow-sm relative overflow-hidden">
        <div className="absolute top-0 right-0 p-10 opacity-[0.03]">
          <Globe className="w-64 h-64 rotate-12" />
        </div>
        
        <div className="relative z-10 max-w-3xl">
          <div className="flex items-center space-x-3 mb-6">
            <div className="p-3 bg-indigo-600 rounded-2xl text-white shadow-lg shadow-indigo-100">
              <Terminal className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-2xl font-black text-gray-900 tracking-tight">Data Scraper</h3>
              <p className="text-sm font-medium text-gray-500">Live property extraction & market intelligence.</p>
            </div>
          </div>

          <form onSubmit={handleScrape} className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input 
                type="text" 
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Paste URL or type search (e.g., 'Zillow listings in Miami beach under $1M')"
                className="w-full pl-12 pr-6 py-4 bg-gray-50 border-none rounded-2xl focus:ring-2 focus:ring-indigo-500 font-medium transition-all"
              />
            </div>
            <button 
              disabled={loading || !query.trim()}
              className="px-8 py-4 bg-gray-900 text-white rounded-2xl font-black text-sm uppercase tracking-widest hover:bg-black transition-all shadow-xl shadow-gray-200 disabled:opacity-50 flex items-center justify-center whitespace-nowrap"
            >
              {loading ? <Loader2 className="w-5 h-5 animate-spin mr-2" /> : <Zap className="w-5 h-5 mr-2 text-indigo-400 fill-current" />}
              {loading ? 'Crawling...' : 'Scrape Web'}
            </button>
          </form>

          <div className="mt-6 flex items-start space-x-3 p-4 bg-indigo-50/50 rounded-2xl border border-indigo-100/50">
            <Info className="w-4 h-4 text-indigo-500 mt-0.5 flex-shrink-0" />
            <p className="text-[10px] font-bold text-indigo-600/70 uppercase tracking-widest leading-relaxed">
              Grounding active. Every result is cross-referenced with live Google Search data for accuracy and verified URLs.
            </p>
          </div>
        </div>
      </div>

      {/* Results View */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          <div className="flex items-center justify-between px-2">
            <h4 className="text-[10px] font-black uppercase tracking-widest text-gray-400">Extracted Intelligence</h4>
            {loading && (
              <div className="flex items-center space-x-2 text-indigo-600 font-black text-[10px] uppercase tracking-widest">
                <span className="animate-pulse">{status}</span>
              </div>
            )}
          </div>

          <AnimatePresence mode="wait">
            {results.length > 0 ? (
              <div className="grid gap-6">
                {results.map((listing, i) => (
                  <motion.div 
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.1 }}
                    key={i} 
                    className="bg-white p-6 rounded-[32px] border shadow-sm group hover:shadow-xl hover:border-indigo-100 transition-all flex items-start space-x-6"
                  >
                    <div className="w-16 h-16 rounded-2xl bg-gray-50 border flex flex-col items-center justify-center text-gray-400 group-hover:bg-indigo-600 group-hover:text-white transition-all">
                      <Building2 className="w-6 h-6" />
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between mb-2">
                        <h5 className="text-lg font-black text-gray-900 truncate pr-4">{listing.address}</h5>
                        <span className="text-lg font-black text-indigo-600 whitespace-nowrap">{listing.price}</span>
                      </div>
                      
                      <div className="flex items-center space-x-4 mb-4 text-xs font-bold text-gray-400 uppercase tracking-widest">
                        <span className="flex items-center"><MapPin className="w-3 h-3 mr-1" /> Verified</span>
                        <span className="flex items-center"><Zap className="w-3 h-3 mr-1" /> AI Parsed</span>
                      </div>

                      <p className="text-sm text-gray-500 font-medium line-clamp-2 mb-6 bg-gray-50 p-4 rounded-2xl border border-gray-100 italic">
                        "{listing.details}"
                      </p>

                      <div className="flex items-center space-x-3">
                        <button 
                          onClick={() => handleImport(listing)}
                          className="flex items-center px-4 py-2 bg-indigo-600 text-white text-[10px] font-black uppercase tracking-widest rounded-xl hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100"
                        >
                          <UserPlus className="w-3 h-3 mr-2" />
                          Import as Lead
                        </button>
                        <a 
                          href={listing.sourceUrl} 
                          target="_blank" 
                          className="p-2 text-gray-400 hover:text-indigo-600 bg-gray-50 hover:bg-white border border-transparent hover:border-indigo-100 rounded-xl transition-all"
                        >
                          <ExternalLink className="w-4 h-4" />
                        </a>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            ) : !loading && (
              <div className="py-32 text-center bg-gray-50 rounded-[40px] border-2 border-dashed border-gray-200">
                <Globe className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                <p className="text-sm font-bold text-gray-400 uppercase tracking-widest">No active crawl results</p>
                <p className="text-xs text-gray-400 mt-2">Enter a listing URL or query above to start scraping.</p>
              </div>
            )}
          </AnimatePresence>
        </div>

        {/* Sources & Metadata */}
        <div className="space-y-8">
          <div className="bg-gray-900 rounded-[40px] p-8 text-white shadow-2xl">
            <h4 className="text-[10px] font-black uppercase tracking-[0.2em] text-indigo-400 mb-6 flex items-center">
              <Globe className="w-4 h-4 mr-2" /> Grounding Sources
            </h4>
            
            <div className="space-y-4">
              {groundingChunks.length > 0 ? (
                groundingChunks.map((chunk, i) => (
                  <a 
                    key={i} 
                    href={chunk.web?.uri} 
                    target="_blank" 
                    className="block p-4 bg-white/5 rounded-2xl border border-white/10 hover:bg-white/10 transition-all group"
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-[10px] font-black uppercase tracking-widest text-gray-500">Source {i+1}</span>
                      <ExternalLink className="w-3 h-3 text-gray-600 group-hover:text-indigo-400" />
                    </div>
                    <p className="text-xs font-bold text-gray-300 truncate">{chunk.web?.title}</p>
                    <p className="text-[9px] text-indigo-400/60 truncate mt-1">{chunk.web?.uri}</p>
                  </a>
                ))
              ) : (
                <div className="py-12 text-center opacity-20">
                  <p className="text-xs font-bold uppercase tracking-widest">Awaiting Crawl...</p>
                </div>
              )}
            </div>
          </div>

          <div className="bg-white rounded-[32px] p-8 border shadow-sm">
            <h4 className="text-[10px] font-black uppercase tracking-widest text-gray-400 mb-6">Market Trends</h4>
            <div className="space-y-4">
              {[
                { label: 'Miami Ave Price', val: '$1.2M', trend: '+4%' },
                { label: 'Inventory Level', val: 'Low', trend: '-2%' },
                { label: 'Avg Days on Market', val: '22', trend: 'Stable' },
              ].map((stat, i) => (
                <div key={i} className="flex justify-between items-center p-3 bg-gray-50 rounded-2xl">
                  <div>
                    <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">{stat.label}</p>
                    <p className="text-sm font-black text-gray-900">{stat.val}</p>
                  </div>
                  <span className={`text-[10px] font-black px-2 py-1 rounded-lg ${stat.trend.includes('+') ? 'text-emerald-600 bg-emerald-50' : 'text-amber-600 bg-amber-50'}`}>
                    {stat.trend}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default WebProspector;
