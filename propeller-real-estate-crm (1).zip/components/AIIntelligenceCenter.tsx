
import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI, Modality, Type, LiveServerMessage } from "@google/genai";
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Mic, 
  MicOff, 
  Sparkles, 
  BrainCircuit, 
  FileSearch, 
  TrendingUp, 
  Languages, 
  Loader2, 
  Upload, 
  Plus, 
  ChevronRight, 
  Volume2, 
  Zap,
  MessageSquare,
  Bot
} from 'lucide-react';
import { Lead, Task } from '../types.ts';

interface AIIntelligenceCenterProps {
  onAddLead: (lead: Omit<Lead, 'id'>) => void;
  onAddTask: (task: Omit<Task, 'id'>) => void;
}

const AIIntelligenceCenter: React.FC<AIIntelligenceCenterProps> = ({ onAddLead, onAddTask }) => {
  const [activeMode, setActiveMode] = useState<'voice' | 'vision' | 'predict'>('voice');
  const [isListening, setIsListening] = useState(false);
  const [transcription, setTranscription] = useState('');
  const [aiResponseText, setAiResponseText] = useState('');
  const [status, setStatus] = useState('');
  const [previewImage, setPreviewImage] = useState<string | null>(null);
  
  // Voice API Refs
  const audioContextRef = useRef<AudioContext | null>(null);
  const inputStreamRef = useRef<MediaStream | null>(null);
  const nextStartTimeRef = useRef<number>(0);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());

  // --- Live API Helper Methods ---
  const encode = (bytes: Uint8Array) => {
    let binary = '';
    const len = bytes.byteLength;
    for (let i = 0; i < len; i++) binary += String.fromCharCode(bytes[i]);
    return btoa(binary);
  };

  const decode = (base64: string) => {
    const binaryString = atob(base64);
    const bytes = new Uint8Array(binaryString.length);
    for (let i = 0; i < binaryString.length; i++) bytes[i] = binaryString.charCodeAt(i);
    return bytes;
  };

  const decodeAudioData = async (data: Uint8Array, ctx: AudioContext) => {
    const dataInt16 = new Int16Array(data.buffer);
    const frameCount = dataInt16.length;
    const buffer = ctx.createBuffer(1, frameCount, 24000);
    const channelData = buffer.getChannelData(0);
    for (let i = 0; i < frameCount; i++) channelData[i] = dataInt16[i] / 32768.0;
    return buffer;
  };

  const createBlob = (data: Float32Array) => {
    const int16 = new Int16Array(data.length);
    for (let i = 0; i < data.length; i++) int16[i] = data[i] * 32768;
    return { data: encode(new Uint8Array(int16.buffer)), mimeType: 'audio/pcm;rate=16000' };
  };

  const startVoiceSession = async () => {
    if (isListening) return;
    
    setIsListening(true);
    setStatus('Activating Neural Link...');
    setAiResponseText('');
    setTranscription('');

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      audioContextRef.current = audioCtx;
      
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      inputStreamRef.current = stream;

      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-12-2025',
        callbacks: {
          onopen: () => {
            const inputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
            const source = inputCtx.createMediaStreamSource(stream);
            const processor = inputCtx.createScriptProcessor(4096, 1, 1);
            
            processor.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              const pcmBlob = createBlob(inputData);
              sessionPromise.then(s => s.sendRealtimeInput({ media: pcmBlob }));
            };
            
            source.connect(processor);
            processor.connect(inputCtx.destination);
            setStatus('Neural Link Established. Speak now.');
          },
          onmessage: async (msg: LiveServerMessage) => {
            if (msg.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data) {
              const base64 = msg.serverContent.modelTurn.parts[0].inlineData.data;
              const bytes = decode(base64);
              const buffer = await decodeAudioData(bytes, audioCtx);
              const source = audioCtx.createBufferSource();
              source.buffer = buffer;
              source.connect(audioCtx.destination);
              nextStartTimeRef.current = Math.max(nextStartTimeRef.current, audioCtx.currentTime);
              source.start(nextStartTimeRef.current);
              nextStartTimeRef.current += buffer.duration;
              sourcesRef.current.add(source);
            }

            if (msg.serverContent?.outputTranscription) {
              setAiResponseText(prev => prev + msg.serverContent!.outputTranscription!.text);
            }
            if (msg.serverContent?.inputTranscription) {
              setTranscription(prev => prev + msg.serverContent!.inputTranscription!.text);
            }

            if (msg.toolCall) {
              for (const fc of msg.toolCall.functionCalls) {
                console.log('AI Tool Call:', fc);
                let result = "Action performed successfully.";
                if (fc.name === 'createLead') {
                  onAddLead(fc.args as any);
                  result = `Lead ${fc.args.name} added to pipeline.`;
                }
                sessionPromise.then(s => s.sendToolResponse({ 
                  functionResponses: { id: fc.id, name: fc.name, response: { result } } 
                }));
              }
            }
          },
          onclose: () => stopVoiceSession(),
          onerror: (e) => { console.error(e); stopVoiceSession(); }
        },
        config: {
          responseModalities: [Modality.AUDIO],
          systemInstruction: 'You are Propeller, a premium Real Estate CRM Assistant. You help agents manage their pipeline. You can create leads and tasks.',
          inputAudioTranscription: {},
          outputAudioTranscription: {},
          speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } } },
          tools: [{
            functionDeclarations: [
              {
                name: 'createLead',
                parameters: {
                  type: Type.OBJECT,
                  properties: {
                    name: { type: Type.STRING },
                    propertyInterest: { type: Type.STRING },
                    value: { type: Type.NUMBER },
                    status: { type: Type.STRING, enum: ['New', 'Qualified', 'Closed'] }
                  },
                  required: ['name', 'propertyInterest', 'value']
                }
              }
            ]
          }]
        }
      });

    } catch (e) {
      console.error(e);
      stopVoiceSession();
    }
  };

  const stopVoiceSession = () => {
    setIsListening(false);
    setStatus('');
    inputStreamRef.current?.getTracks().forEach(t => t.stop());
    sourcesRef.current.forEach(s => s.stop());
    sourcesRef.current.clear();
    audioContextRef.current?.close();
  };

  const handleVisionExtract = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onloadend = async () => {
      const base64 = reader.result as string;
      setPreviewImage(base64);
      setStatus('Analyzing Document Content...');
      
      try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const response = await ai.models.generateContent({
          model: 'gemini-3-flash-preview',
          contents: {
            parts: [
              { text: "Extract lead information from this document. Return JSON format with name, email, propertyInterest, and value." },
              { inlineData: { data: base64.split(',')[1], mimeType: file.type } }
            ]
          },
          config: { responseMimeType: 'application/json' }
        });

        if (response.text) {
          const data = JSON.parse(response.text);
          onAddLead({
            name: data.name || "Unknown Lead",
            email: data.email || "no-email@example.com",
            phone: "N/A",
            status: "New",
            value: data.value || 0,
            propertyInterest: data.propertyInterest || "Unspecified",
            location: "Parsed from document",
            notes: ["Extracted via Propeller Vision ML"],
            lastInteraction: new Date().toISOString().split('T')[0],
            createdAt: new Date().toISOString().split('T')[0]
          });
          alert("Lead successfully extracted from document!");
        }
      } catch (err) {
        console.error(err);
      } finally {
        setStatus('');
        setPreviewImage(null);
      }
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 h-full">
      {/* Tool Selection Sidebar */}
      <div className="lg:col-span-3 space-y-4">
        {[
          { id: 'voice', label: 'Neural Voice', icon: Mic, desc: 'Real-time CRM interaction' },
          { id: 'vision', label: 'Doc Vision', icon: FileSearch, desc: 'OCR & Lead extraction' },
          { id: 'predict', label: 'Predictive ML', icon: TrendingUp, desc: 'Market forecasting' },
        ].map((tool) => (
          <button
            key={tool.id}
            onClick={() => setActiveMode(tool.id as any)}
            className={`w-full p-6 rounded-[32px] border transition-all text-left flex items-start space-x-4 ${
              activeMode === tool.id 
                ? 'bg-indigo-600 text-white shadow-xl shadow-indigo-100 border-indigo-500 scale-[1.02]' 
                : 'bg-white text-gray-900 border-gray-100 hover:border-indigo-200 shadow-sm'
            }`}
          >
            <div className={`p-3 rounded-2xl ${activeMode === tool.id ? 'bg-white/10' : 'bg-gray-50 text-indigo-500'}`}>
              <tool.icon className="w-6 h-6" />
            </div>
            <div>
              <p className="text-sm font-black uppercase tracking-widest">{tool.label}</p>
              <p className={`text-xs mt-1 ${activeMode === tool.id ? 'text-indigo-100' : 'text-gray-400'}`}>{tool.desc}</p>
            </div>
          </button>
        ))}
        
        <div className="mt-12 bg-gray-900 rounded-[32px] p-6 text-white border border-white/5 relative overflow-hidden">
          <div className="relative z-10">
            <h4 className="text-[10px] font-black uppercase tracking-widest text-indigo-400 mb-4 flex items-center">
              <Zap className="w-3 h-3 mr-2 fill-current" /> System Status
            </h4>
            <div className="space-y-3">
              <div className="flex justify-between items-center text-[10px] font-bold">
                <span className="text-gray-500 uppercase">Latency</span>
                <span className="text-emerald-400">22ms</span>
              </div>
              <div className="flex justify-between items-center text-[10px] font-bold">
                <span className="text-gray-500 uppercase">Context Window</span>
                <span className="text-indigo-400">128k</span>
              </div>
            </div>
          </div>
          <div className="absolute top-0 right-0 w-24 h-24 bg-indigo-500/10 blur-2xl rounded-full"></div>
        </div>
      </div>

      {/* Primary Interaction Area */}
      <div className="lg:col-span-9">
        <AnimatePresence mode="wait">
          {activeMode === 'voice' && (
            <motion.div
              key="voice"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="bg-white h-full rounded-[40px] border shadow-sm p-12 flex flex-col items-center justify-center text-center space-y-12 relative overflow-hidden"
            >
              {/* Orb Visualization */}
              <div className="relative">
                <motion.div 
                  animate={{ 
                    scale: isListening ? [1, 1.1, 1] : 1,
                    rotate: isListening ? 360 : 0 
                  }}
                  transition={{ repeat: Infinity, duration: 3 }}
                  className={`w-48 h-48 rounded-full flex items-center justify-center relative z-10 transition-all duration-500 ${
                    isListening 
                      ? 'bg-gradient-to-tr from-indigo-600 via-purple-600 to-rose-600 shadow-[0_0_50px_rgba(79,70,229,0.5)]' 
                      : 'bg-gray-100'
                  }`}
                >
                  <div className="absolute inset-2 bg-white rounded-full flex items-center justify-center">
                    {isListening ? (
                      <div className="flex items-center space-x-1">
                        {[1, 2, 3, 4, 5].map(i => (
                          <motion.div
                            key={i}
                            animate={{ height: [10, 40, 10] }}
                            transition={{ repeat: Infinity, duration: 0.5, delay: i * 0.1 }}
                            className="w-1.5 bg-indigo-600 rounded-full"
                          />
                        ))}
                      </div>
                    ) : (
                      <Bot className="w-16 h-16 text-gray-200" />
                    )}
                  </div>
                </motion.div>
                {isListening && (
                  <motion.div 
                    initial={{ scale: 0.8, opacity: 0 }}
                    animate={{ scale: 1.5, opacity: [0, 0.2, 0] }}
                    transition={{ repeat: Infinity, duration: 2 }}
                    className="absolute inset-0 bg-indigo-400 rounded-full z-0"
                  />
                )}
              </div>

              <div className="space-y-4 max-w-md">
                <h3 className="text-3xl font-black text-gray-900 tracking-tight">
                  {isListening ? 'Listening...' : 'Neural CRM Voice'}
                </h3>
                <p className="text-gray-500 font-medium">
                  {status || 'Interact with your entire CRM using natural language. Try saying "Add a lead for 1M value."'}
                </p>
              </div>

              <div className="flex flex-col items-center space-y-8 w-full">
                <button 
                  onClick={isListening ? stopVoiceSession : startVoiceSession}
                  className={`group p-8 rounded-full transition-all active:scale-90 ${
                    isListening ? 'bg-rose-50 text-rose-500 hover:bg-rose-100' : 'bg-indigo-600 text-white shadow-xl shadow-indigo-100 hover:bg-indigo-700'
                  }`}
                >
                  {isListening ? <MicOff className="w-10 h-10" /> : <Mic className="w-10 h-10" />}
                </button>

                <div className="w-full max-w-2xl bg-gray-50 rounded-3xl p-6 min-h-[120px] text-left border border-gray-100 relative group overflow-hidden">
                  <div className="flex items-center space-x-2 mb-4">
                    <MessageSquare className="w-4 h-4 text-gray-400" />
                    <span className="text-[10px] font-black uppercase text-gray-400 tracking-widest">Live Thought Stream</span>
                  </div>
                  <div className="space-y-2">
                    {transcription && (
                      <p className="text-sm font-bold text-gray-700 bg-white/80 p-3 rounded-2xl border border-gray-100 shadow-sm animate-in slide-in-from-left-2">
                        You: {transcription}
                      </p>
                    )}
                    {aiResponseText && (
                      <p className="text-sm font-bold text-indigo-600 bg-indigo-50 p-3 rounded-2xl border border-indigo-100 shadow-sm animate-in slide-in-from-right-2">
                        Propeller: {aiResponseText}
                      </p>
                    )}
                    {!transcription && !aiResponseText && (
                      <p className="text-sm text-gray-300 italic">Conversation log will appear here...</p>
                    )}
                  </div>
                  <div className="absolute -bottom-1 left-0 w-full h-1 bg-indigo-600/10 group-hover:bg-indigo-600/30 transition-colors"></div>
                </div>
              </div>
            </motion.div>
          )}

          {activeMode === 'vision' && (
            <motion.div
              key="vision"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="bg-white h-full rounded-[40px] border shadow-sm p-12 flex flex-col"
            >
              <div className="flex items-center space-x-4 mb-12">
                <div className="p-4 bg-indigo-50 text-indigo-600 rounded-[20px]">
                  <FileSearch className="w-8 h-8" />
                </div>
                <div>
                  <h3 className="text-2xl font-black text-gray-900 tracking-tight">Multimodal Document Intelligence</h3>
                  <p className="text-gray-500 font-medium">Upload property listings or brochures to automatically create leads.</p>
                </div>
              </div>

              <div className="flex-1 border-2 border-dashed border-gray-100 rounded-[40px] flex flex-col items-center justify-center p-12 transition-all hover:border-indigo-200 hover:bg-gray-50/50 group">
                {previewImage ? (
                  <div className="relative max-w-sm">
                    <img src={previewImage} className="rounded-3xl shadow-2xl border-4 border-white" />
                    <div className="absolute inset-0 bg-indigo-600/20 backdrop-blur-[2px] rounded-3xl flex items-center justify-center">
                      <Loader2 className="w-12 h-12 text-white animate-spin" />
                    </div>
                  </div>
                ) : (
                  <>
                    <div className="w-24 h-24 bg-white rounded-[32px] shadow-sm flex items-center justify-center mb-8 group-hover:scale-110 transition-transform">
                      <Upload className="w-10 h-10 text-gray-300" />
                    </div>
                    <label className="cursor-pointer">
                      <span className="px-8 py-4 bg-gray-900 text-white rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-black shadow-xl shadow-gray-200 block">
                        Browse Files
                      </span>
                      <input type="file" className="hidden" accept="image/*" onChange={handleVisionExtract} />
                    </label>
                    <p className="text-gray-400 text-xs font-bold uppercase tracking-widest mt-6">Drag and drop documents here</p>
                  </>
                )}
              </div>
            </motion.div>
          )}

          {activeMode === 'predict' && (
            <motion.div
              key="predict"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="bg-white h-full rounded-[40px] border shadow-sm p-12 overflow-y-auto custom-scroll"
            >
              <div className="flex items-center space-x-4 mb-12">
                <div className="p-4 bg-emerald-50 text-emerald-600 rounded-[20px]">
                  <TrendingUp className="w-8 h-8" />
                </div>
                <div>
                  <h3 className="text-2xl font-black text-gray-900 tracking-tight">Market Predictive Analytics</h3>
                  <p className="text-gray-500 font-medium">AI-driven forecasts based on current macroeconomic grounding.</p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="p-8 bg-gray-900 rounded-[40px] text-white shadow-2xl relative overflow-hidden">
                  <h4 className="text-[10px] font-black uppercase tracking-[0.2em] text-emerald-400 mb-8 flex items-center">
                    <Sparkles className="w-4 h-4 mr-2" /> 12-Month Projection
                  </h4>
                  <div className="space-y-8 relative z-10">
                    <div>
                      <p className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-1">Estimated Growth</p>
                      <p className="text-5xl font-black">+8.42%</p>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="p-4 bg-white/5 rounded-2xl border border-white/10">
                        <p className="text-[9px] font-black text-gray-500 uppercase tracking-widest mb-1">Confidence</p>
                        <p className="text-lg font-black">92%</p>
                      </div>
                      <div className="p-4 bg-white/5 rounded-2xl border border-white/10">
                        <p className="text-[9px] font-black text-gray-500 uppercase tracking-widest mb-1">Stability</p>
                        <p className="text-lg font-black text-emerald-400">High</p>
                      </div>
                    </div>
                  </div>
                  <div className="absolute -right-10 -bottom-10 w-48 h-48 bg-emerald-500/20 blur-3xl rounded-full"></div>
                </div>

                <div className="p-8 bg-indigo-50/50 rounded-[40px] border border-indigo-100 flex flex-col justify-between">
                  <div>
                    <h4 className="text-[10px] font-black uppercase tracking-widest text-indigo-600 mb-6">AI Market Sentiment</h4>
                    <p className="text-lg font-bold text-gray-800 leading-relaxed italic">
                      "Recent trends in tech-hub relocation suggest a strong Q3 for suburban luxury properties. Austin and Miami continue to lead high-value transactions."
                    </p>
                  </div>
                  <button className="w-full py-4 bg-white text-indigo-600 border border-indigo-200 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-indigo-50 transition-all flex items-center justify-center">
                    Download Full Report <ChevronRight className="w-4 h-4 ml-2" />
                  </button>
                </div>
              </div>

              <div className="mt-12 p-10 bg-white rounded-[40px] border border-gray-100 shadow-sm">
                <div className="flex items-center justify-between mb-8">
                  <h4 className="text-[10px] font-black uppercase tracking-widest text-gray-400">ML Training Set Statistics</h4>
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 rounded-full bg-emerald-500"></div>
                    <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Active</span>
                  </div>
                </div>
                <div className="flex space-x-12">
                  <div>
                    <p className="text-3xl font-black text-gray-900">42k+</p>
                    <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Points analyzed</p>
                  </div>
                  <div className="w-px h-12 bg-gray-100"></div>
                  <div>
                    <p className="text-3xl font-black text-gray-900">10ms</p>
                    <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Inference speed</p>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

export default AIIntelligenceCenter;
