
import React, { useState, useMemo } from 'react';
import Sidebar from './components/Sidebar.tsx';
import Dashboard from './components/Dashboard.tsx';
import LeadList from './components/LeadList.tsx';
import TaskView from './components/TaskView.tsx';
import LeadDetailModal from './components/LeadDetailModal.tsx';
import CreativeStudio from './components/CreativeStudio.tsx';
import WebProspector from './components/WebProspector.tsx';
import AIIntelligenceCenter from './components/AIIntelligenceCenter.tsx';
import { INITIAL_LEADS, INITIAL_TASKS } from './constants.tsx';
import { Lead, Task, RecurrencePattern } from './types.ts';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Bell, Search } from 'lucide-react';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'leads' | 'tasks' | 'studio' | 'prospector' | 'intelligence'>('dashboard');
  const [leads, setLeads] = useState<Lead[]>(INITIAL_LEADS);
  const [tasks, setTasks] = useState<Task[]>(INITIAL_TASKS);
  const [selectedLead, setSelectedLead] = useState<Lead | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  const calculateNextDueDate = (currentDate: string, recurrence: RecurrencePattern): string => {
    const date = new Date(currentDate);
    if (recurrence === 'Daily') date.setDate(date.getDate() + 1);
    else if (recurrence === 'Weekly') date.setDate(date.getDate() + 7);
    else if (recurrence === 'Monthly') date.setMonth(date.getMonth() + 1);
    return date.toISOString().split('T')[0];
  };

  const toggleTaskCompletion = (id: string) => {
    setTasks(prev => {
      const taskIndex = prev.findIndex(t => t.id === id);
      if (taskIndex === -1) return prev;

      const updatedTasks = [...prev];
      const task = updatedTasks[taskIndex];
      const newCompletedState = !task.completed;
      updatedTasks[taskIndex] = { ...task, completed: newCompletedState };

      if (newCompletedState && task.recurrence && task.recurrence !== 'None') {
        const nextTask: Task = {
          ...task,
          id: `t${Date.now()}`,
          completed: false,
          dueDate: calculateNextDueDate(task.dueDate, task.recurrence),
          subtasks: task.subtasks.map(s => ({ ...s, completed: false }))
        };
        updatedTasks.unshift(nextTask);
      }
      return updatedTasks;
    });
  };

  const bulkToggleComplete = (ids: string[], completed: boolean) => {
    setTasks(prev => {
      let updated = prev.map(task => ids.includes(task.id) ? { ...task, completed } : task);
      if (completed) {
        const spawned: Task[] = [];
        ids.forEach(id => {
          const task = prev.find(t => t.id === id);
          if (task && !task.completed && task.recurrence && task.recurrence !== 'None') {
            spawned.push({
              ...task,
              id: `t${Date.now()}-${id}`,
              completed: false,
              dueDate: calculateNextDueDate(task.dueDate, task.recurrence),
              subtasks: task.subtasks.map(s => ({ ...s, completed: false }))
            });
          }
        });
        return [...spawned, ...updated];
      }
      return updated;
    });
  };

  const deleteTasks = (ids: string[]) => {
    setTasks(prev => prev.filter(t => !ids.includes(t.id)));
  };

  const addTask = (newTask: Omit<Task, 'id'>) => {
    setTasks(prev => [{ ...newTask, id: `t${Date.now()}` }, ...prev]);
  };

  const updateTask = (updatedTask: Task) => {
    setTasks(prev => prev.map(t => t.id === updatedTask.id ? updatedTask : t));
  };

  const addLead = (newLead: Omit<Lead, 'id'>) => {
    setLeads(prev => [{ ...newLead, id: `l${Date.now()}` }, ...prev]);
  };

  const updateLead = (updatedLead: Lead) => {
    setLeads(prev => prev.map(l => l.id === updatedLead.id ? updatedLead : l));
  };

  const filteredLeads = useMemo(() => {
    if (!searchQuery) return leads;
    const q = searchQuery.toLowerCase();
    return leads.filter(l => 
      l.name.toLowerCase().includes(q) || 
      l.email.toLowerCase().includes(q) || 
      l.propertyInterest.toLowerCase().includes(q)
    );
  }, [leads, searchQuery]);

  const filteredTasks = useMemo(() => {
    if (!searchQuery) return tasks;
    const q = searchQuery.toLowerCase();
    return tasks.filter(t => t.title.toLowerCase().includes(q));
  }, [tasks, searchQuery]);

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <Dashboard leads={filteredLeads} tasks={filteredTasks} onSelectLead={setSelectedLead} />;
      case 'leads':
        return <LeadList leads={filteredLeads} onSelectLead={setSelectedLead} onAddLead={addLead} onUpdateLead={updateLead} />;
      case 'tasks':
        return (
          <TaskView 
            tasks={filteredTasks} 
            leads={leads}
            onToggleComplete={toggleTaskCompletion} 
            onAddTask={addTask}
            onUpdateTask={updateTask}
            onBulkToggleComplete={bulkToggleComplete}
            onDeleteTasks={deleteTasks}
          />
        );
      case 'prospector':
        return <WebProspector onImportLead={addLead} />;
      case 'studio':
        return <CreativeStudio />;
      case 'intelligence':
        return <AIIntelligenceCenter onAddLead={addLead} onAddTask={addTask} />;
      default:
        return <Dashboard leads={filteredLeads} tasks={filteredTasks} onSelectLead={setSelectedLead} />;
    }
  };

  return (
    <div className="flex min-h-screen bg-[#fcfdff]">
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />
      
      <main className="flex-1 px-10 py-12 max-w-7xl mx-auto w-full">
        <header className="flex flex-col sm:flex-row sm:items-center justify-between mb-12 gap-6">
          <motion.div 
            key={activeTab}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="space-y-1"
          >
            <h2 className="text-4xl font-black text-gray-900 tracking-tight capitalize">{activeTab === 'intelligence' ? 'AI Intelligence' : activeTab.replace('prospector', 'Prospector')}</h2>
            <p className="text-gray-500 font-medium">
              {activeTab === 'intelligence' 
                ? 'Advanced Neural-ML suite for pipeline management.'
                : activeTab === 'prospector' 
                ? 'Scrape listing data and market intelligence directly from the web.'
                : activeTab === 'studio'
                ? 'Generate high-end property marketing materials instantly.'
                : `You have ${tasks.filter(t => !t.completed).length} items requiring your attention today.`
              }
            </p>
          </motion.div>

          <div className="flex items-center space-x-3">
            <div className="hidden lg:flex items-center bg-white border border-gray-100 rounded-2xl px-4 py-2 shadow-sm focus-within:ring-2 focus-within:ring-indigo-100 transition-all">
              <Search className="w-4 h-4 text-gray-400 mr-2" />
              <input 
                type="text" 
                placeholder="Global search..." 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="bg-transparent border-none text-sm focus:outline-none w-48 font-medium" 
              />
            </div>
            <button className="relative p-3 text-gray-400 hover:text-gray-900 bg-white border border-gray-100 rounded-2xl shadow-sm transition-all hover:shadow-md">
              <Bell className="w-5 h-5" />
              <span className="absolute top-2.5 right-2.5 w-2 h-2 bg-rose-500 rounded-full border-2 border-white"></span>
            </button>
            <button 
              onClick={() => setActiveTab('leads')}
              className="flex items-center px-6 py-3 bg-indigo-600 text-white rounded-2xl font-black text-sm hover:bg-indigo-700 shadow-xl shadow-indigo-100 transition-all active:scale-95 uppercase tracking-widest"
            >
              <Plus className="w-5 h-5 mr-2" />
              New Lead
            </button>
          </div>
        </header>

        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
            className="h-full"
          >
            {renderContent()}
          </motion.div>
        </AnimatePresence>

        <AnimatePresence>
          {selectedLead && (
            <LeadDetailModal 
              lead={selectedLead} 
              onClose={() => setSelectedLead(null)} 
              onAddTask={addTask}
            />
          )}
        </AnimatePresence>
      </main>
    </div>
  );
};

export default App;
