
import { GoogleGenAI, Type } from "@google/genai";
import { Lead, AIInsight } from "../types";

export const analyzeLead = async (lead: Lead): Promise<AIInsight | null> => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
    
    const prompt = `Analyze this real estate lead and provide a summary, suggested next action, sentiment, and a priority score (1-100).
    Lead Name: ${lead.name}
    Status: ${lead.status}
    Property: ${lead.propertyInterest}
    Value: $${lead.value}
    Notes: ${lead.notes.join(' ')}
    Last Interaction: ${lead.lastInteraction}`;

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            summary: { type: Type.STRING },
            suggestedAction: { type: Type.STRING },
            sentiment: { 
              type: Type.STRING,
              description: "Must be one of: Positive, Neutral, Concerned"
            },
            priorityScore: { type: Type.NUMBER }
          },
          required: ["summary", "suggestedAction", "sentiment", "priorityScore"]
        }
      }
    });

    if (response.text) {
      return JSON.parse(response.text) as AIInsight;
    }
    return null;
  } catch (error) {
    console.error("Error analyzing lead:", error);
    return null;
  }
};
