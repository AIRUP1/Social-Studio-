
import React from 'react';
import { Lead, Task } from './types';

export const INITIAL_LEADS: Lead[] = [
  {
    id: '1',
    name: 'Sarah Jenkins',
    email: 'sarah.j@example.com',
    phone: '(555) 123-4567',
    status: 'Qualified',
    value: 850000,
    propertyInterest: 'Luxury Waterfront Villa',
    location: 'Miami Beach',
    notes: [
      'Interested in 4+ bedrooms.',
      'Needs a home office.',
      'Last call: She is looking to move within 3 months.'
    ],
    lastInteraction: '2023-11-20',
    createdAt: '2023-10-15'
  },
  {
    id: '2',
    name: 'Robert Miller',
    email: 'robert.m@company.com',
    phone: '(555) 987-6543',
    status: 'Negotiation',
    value: 1200000,
    propertyInterest: 'Downtown Penthouse',
    location: 'Chicago',
    notes: [
      'Cash buyer.',
      'Has some concerns about HOA fees.',
      'Requested a second viewing for Friday.'
    ],
    lastInteraction: '2023-11-22',
    createdAt: '2023-09-20'
  },
  {
    id: '3',
    name: 'Elena Rodriguez',
    email: 'elena.r@email.com',
    phone: '(555) 456-7890',
    status: 'New',
    value: 450000,
    propertyInterest: 'Suburban Family Home',
    location: 'Austin',
    notes: [
      'First-time home buyer.',
      'Working with a lender currently.'
    ],
    lastInteraction: '2023-11-23',
    createdAt: '2023-11-23'
  }
];

export const INITIAL_TASKS: Task[] = [
  {
    id: 't1',
    leadId: '1',
    title: 'Send floor plans',
    description: 'Email the PDF floor plans for the Miami villa.',
    dueDate: '2023-11-25',
    priority: 'High',
    completed: false,
    recurrence: 'None',
    subtasks: [
      { id: 's1', title: 'Export PDF from Revit', completed: true },
      { id: 's2', title: 'Draft email body', completed: false }
    ]
  },
  {
    id: 't2',
    leadId: '2',
    title: 'Confirm viewing',
    description: 'Call Robert to confirm Friday morning viewing.',
    dueDate: '2023-11-24',
    priority: 'Medium',
    completed: true,
    recurrence: 'None',
    subtasks: []
  }
];

export const STATUS_COLORS: Record<string, string> = {
  New: 'bg-blue-100 text-blue-800',
  Contacted: 'bg-yellow-100 text-yellow-800',
  Qualified: 'bg-purple-100 text-purple-800',
  Proposal: 'bg-indigo-100 text-indigo-800',
  Negotiation: 'bg-orange-100 text-orange-800',
  Closed: 'bg-green-100 text-green-800',
  Lost: 'bg-red-100 text-red-800'
};
