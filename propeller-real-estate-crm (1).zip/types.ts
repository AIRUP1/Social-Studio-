
export type LeadStatus = 'New' | 'Contacted' | 'Qualified' | 'Proposal' | 'Negotiation' | 'Closed' | 'Lost';

export interface Lead {
  id: string;
  name: string;
  email: string;
  phone: string;
  status: LeadStatus;
  value: number;
  propertyInterest: string;
  location: string;
  notes: string[];
  lastInteraction: string;
  createdAt: string;
}

export type RecurrencePattern = 'None' | 'Daily' | 'Weekly' | 'Monthly';

export interface Subtask {
  id: string;
  title: string;
  completed: boolean;
}

export interface Task {
  id: string;
  leadId: string;
  title: string;
  description: string;
  dueDate: string;
  priority: 'Low' | 'Medium' | 'High';
  completed: boolean;
  recurrence?: RecurrencePattern;
  subtasks: Subtask[];
}

export interface AIInsight {
  summary: string;
  suggestedAction: string;
  sentiment: 'Positive' | 'Neutral' | 'Concerned';
  priorityScore: number;
}

export interface MediaAsset {
  id: string;
  type: 'image' | 'video';
  url: string;
  prompt: string;
  createdAt: string;
}

export interface ScrapedListing {
  address: string;
  price: string;
  details: string;
  sourceUrl: string;
  agentName?: string;
  status?: string;
}
